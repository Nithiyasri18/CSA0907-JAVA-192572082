# CSA09-192572082-Assignment5

**Student:** NITHIYASRI S  
**Register number:** 192572082  
**Course:** CSA0907 Programming in Java, CO5  
**Java:** Java 17+ (test with `java -version`; intended JDK 21)  

## Task folders
TaskA1: binary bus-pass layout demonstration. TaskA2: buffered line counting. TaskA3: generic DAO. TaskA4: serialization and transient fields. TaskA5: JDBC wallet transaction. TaskB1: file store, completed faculty TODO, file-size and growth benchmarks. TaskB2: SQL injection demonstration against **local test database only**, and damaged-file tests. TaskB3: completed batch loader, schema, JDBC performance comparison and rollback test. TaskB4: validated migration and DatabaseMetaData.

## Run standard-library tasks
From a terminal, enter the relevant folder and use `javac FileName.java` followed by `java ClassName`. For the two B1 programs that use PassStore, compile together: `javac PassStore.java PassGrowthBenchmark.java` then `java PassGrowthBenchmark`. For TaskB2 damaged test, copy PassStore.java into that folder or compile with `javac -d . TaskB1/PassStore.java TaskB2/DamagedPassTest.java` from repository root and run `java DamagedPassTest`.

## MySQL setup
Run `TaskB3/schema.sql` in MySQL first. Download and add the official MySQL Connector/J JAR to the Java classpath (do not commit third-party JAR unless permitted). Set `JDBC_URL`, `JDBC_USER`, `JDBC_PASSWORD` environment variables; defaults point to local `assignment5_test`. From repository root compile `javac -d . TaskB3/PassLoader.java TaskB3/JdbcBench.java TaskB2/AdversarialLogin.java TaskA5/WalletTransfer.java TaskB1/BusPassFileStore.java TaskB4/PassMigration.java`. Run with the Connector/J JAR in the classpath, for example on Windows: `java -cp ".;mysql-connector-j-9.x.x.jar" JdbcBench`. Replace `9.x.x` with the actual downloaded version. Run the other database classes similarly. Do not use real credentials or real user data.

## Expected behaviors
PassStore: P1003 found; damaged P1002 not found. HostelSerialization: password and connection are null after load. AdversarialLogin: unsafe login may accept crafted input; prepared login rejects. PassLoader: invalid amount causes rollback and leaves zero rows in an initially empty test table. Migration: invalid records are reported in migration_rejected.txt.

## Evidence and submission
Execute each task locally and save **real** screenshots, console logs, and CSV benchmark results. Record Java/OS/MySQL versions and trial timings. The question paper requires **one Git commit per task**, progressively; do not fabricate a commit history. Create the repository **CSA09-192572082-Assignment5** and place the final repository URL on the report cover. No actual MySQL timings or screenshots are claimed by these starter files.

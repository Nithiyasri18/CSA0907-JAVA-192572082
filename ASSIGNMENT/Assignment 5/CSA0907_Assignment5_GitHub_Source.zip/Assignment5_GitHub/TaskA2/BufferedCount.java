import java.io.*;
import java.nio.file.*;
public class BufferedCount {
    public static void main(String[] args)throws Exception {
        if(args.length!=1){System.out.println("Usage: java BufferedCount <file>");return;}
        long lines=0;try(InputStream in=new BufferedInputStream(Files.newInputStream(Path.of(args[0])))){
            byte[] bytes=new byte[65536];int n;while((n=in.read(bytes))!=-1)for(int i=0;i<n;i++)if(bytes[i]=='\n')lines++;}
        System.out.println("Newline count: "+lines);
    }
}

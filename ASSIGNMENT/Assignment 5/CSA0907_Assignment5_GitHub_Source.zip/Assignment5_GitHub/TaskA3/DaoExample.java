import java.sql.*;
import java.util.*;
interface Dao<T,K> {void insert(T x)throws SQLException;Optional<T> findById(K id)throws SQLException;List<T> findAll()throws SQLException;void update(T x)throws SQLException;void delete(K id)throws SQLException;}
class Student {final String regNo,name;Student(String regNo,String name){this.regNo=regNo;this.name=name;}}
class StudentDao implements Dao<Student,String> {
    private final Connection c;StudentDao(Connection c){this.c=c;}
    public void insert(Student x)throws SQLException {try(PreparedStatement p=c.prepareStatement("INSERT INTO student(reg_no,name) VALUES(?,?)")){p.setString(1,x.regNo);p.setString(2,x.name);p.executeUpdate();}}
    public Optional<Student> findById(String id)throws SQLException {try(PreparedStatement p=c.prepareStatement("SELECT reg_no,name FROM student WHERE reg_no=?")){p.setString(1,id);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(new Student(r.getString(1),r.getString(2))):Optional.empty();}}}
    public List<Student> findAll()throws SQLException {List<Student> out=new ArrayList<>();try(Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT reg_no,name FROM student")){while(r.next())out.add(new Student(r.getString(1),r.getString(2)));}return out;}
    public void update(Student x)throws SQLException {try(PreparedStatement p=c.prepareStatement("UPDATE student SET name=? WHERE reg_no=?")){p.setString(1,x.name);p.setString(2,x.regNo);p.executeUpdate();}}
    public void delete(String id)throws SQLException {try(PreparedStatement p=c.prepareStatement("DELETE FROM student WHERE reg_no=?")){p.setString(1,id);p.executeUpdate();}}
}
public class DaoExample {public static void main(String[] args){System.out.println("Dao<Student,String> interface and JDBC implementation compiled successfully.");}}

import java.sql.*;
import java.math.BigDecimal;
public class WalletTransfer {
    static void transfer(Connection c,BigDecimal amount)throws SQLException {
        boolean previous=c.getAutoCommit();c.setAutoCommit(false);
        try(PreparedStatement debit=c.prepareStatement("UPDATE wallet SET balance=balance-? WHERE id=? AND balance>=?");
            PreparedStatement credit=c.prepareStatement("UPDATE wallet SET balance=balance+? WHERE id=?")){
            debit.setBigDecimal(1,amount);debit.setString(2,"hostel");debit.setBigDecimal(3,amount);
            if(debit.executeUpdate()!=1)throw new SQLException("Insufficient funds");
            credit.setBigDecimal(1,amount);credit.setString(2,"canteen");
            if(credit.executeUpdate()!=1)throw new SQLException("Missing destination wallet");
            c.commit();
        }catch(SQLException|RuntimeException e){try{c.rollback();}catch(SQLException r){e.addSuppressed(r);}throw e;}
        finally{c.setAutoCommit(previous);}
    }
    public static void main(String[] args)throws Exception {
        try(Connection c=DriverManager.getConnection(System.getenv().getOrDefault("JDBC_URL","jdbc:mysql://localhost:3306/assignment5_test"),System.getenv().getOrDefault("JDBC_USER","root"),System.getenv().getOrDefault("JDBC_PASSWORD",""))){transfer(c,new BigDecimal("500.00"));System.out.println("Transfer committed");}
    }
}

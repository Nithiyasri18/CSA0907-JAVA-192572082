import java.nio.file.*;
import java.util.*;
public class PassGrowthBenchmark {
    public static void main(String[] args)throws Exception {
        System.out.println("records,trial,find_last_ns,found");
        for(int n:new int[]{1000,10000,100000}){
            Path p=Files.createTempFile("passgrowth", ".csv");
            try{PassStore s=new PassStore(p);
                try(java.io.BufferedWriter w=Files.newBufferedWriter(p)){
                    for(int i=0;i<n;i++) {w.write("P"+i+",R"+i+",Student"+i+",12,4500.0");w.newLine();}}
                for(int t=1;t<=5;t++){long start=System.nanoTime();String[] found=s.find("P"+(n-1));long elapsed=System.nanoTime()-start;
                    System.out.println(n+","+t+","+elapsed+","+(found!=null));}}
            finally{Files.deleteIfExists(p);}}
    }
}

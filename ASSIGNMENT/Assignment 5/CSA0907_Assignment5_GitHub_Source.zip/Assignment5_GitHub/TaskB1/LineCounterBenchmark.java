import java.io.*;
import java.nio.file.*;
import java.util.*;
public class LineCounterBenchmark {
    static long unbuffered(Path p) throws IOException {long count=0;try(FileInputStream in=new FileInputStream(p.toFile())) {int x;while((x=in.read())!=-1)if(x==10)count++;}return count;}
    static long buffered(Path p) throws IOException {long count=0;try(InputStream in=new BufferedInputStream(Files.newInputStream(p),65536)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1)for(int i=0;i<n;i++)if(b[i]==10)count++;}return count;}
    static void make(Path p,int mb) throws IOException {byte[] line="192572082,Present,2026-11-21\n".getBytes(java.nio.charset.StandardCharsets.UTF_8);
        try(OutputStream o=new BufferedOutputStream(Files.newOutputStream(p))){long left=mb*1024L*1024L;while(left>0){int n=(int)Math.min(line.length,left);o.write(line,0,n);left-=n;}}}
    public static void main(String[] args)throws Exception {System.out.println("size_mb,method,trial,ns,lines");
        for(int mb:new int[]{1,10,50}){Path p=Files.createTempFile("attendance", ".log");try{make(p,mb);
            for(int trial=1;trial<=3;trial++){long t=System.nanoTime(),n=unbuffered(p);long elapsed=System.nanoTime()-t;
                System.out.printf("%d,unbuffered,%d,%d,%d%n",mb,trial,elapsed,n);
                t=System.nanoTime();long m=buffered(p);elapsed=System.nanoTime()-t;
                if(m!=n)throw new AssertionError("Mismatch");
                System.out.printf("%d,buffered,%d,%d,%d%n",mb,trial,elapsed,m);}}
            finally{Files.deleteIfExists(p);}}}
}

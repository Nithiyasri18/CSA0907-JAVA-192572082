import java.io.*;
import java.nio.file.*;
import java.util.*;
public class BusPassFileStore {
    static String escape(String s) { return s.replace("\\", "\\\\").replace("|", "\\p").replace("\n", "\\n"); }
    static String unescape(String s) {
        StringBuilder b = new StringBuilder(); boolean slash=false;
        for (char c : s.toCharArray()) { if (slash) { b.append(c=='p'?'|':c=='n'?'\n':c); slash=false; }
            else if(c=='\\') slash=true; else b.append(c); }
        if(slash) throw new IllegalArgumentException("Bad escape"); return b.toString();
    }
    static String[] parse(String line) {
        String[] x=line.split("\\|",-1); if(x.length!=7) return null;
        try { for(int i=0;i<x.length;i++) x[i]=unescape(x[i]);
            if(x[0].isBlank() || x[1].isBlank() || x[2].isBlank() || x[4].isBlank()) return null;
            Integer.parseInt(x[3]); java.time.LocalDate.parse(x[5]);
            if(Double.parseDouble(x[6])<0) return null; return x;
        } catch(RuntimeException e) { return null; }
    }
    static void add(Path f,String[] x) throws IOException {
        if(x.length!=7) throw new IllegalArgumentException("Seven fields required");
        String[] y=x.clone(); for(int i=0;i<y.length;i++) y[i]=escape(y[i]);
        Files.writeString(f,String.join("|",y)+System.lineSeparator(),StandardOpenOption.CREATE,StandardOpenOption.APPEND);
    }
    static String[] find(Path f,String id) throws IOException {
        if(!Files.exists(f)) return null;
        try(BufferedReader r=Files.newBufferedReader(f)) { String line;
            while((line=r.readLine())!=null) {String[] x=parse(line); if(x!=null && x[0].equals(id)) return x;} }
        return null;
    }
    static List<String[]> route(Path f,int route) throws IOException {
        List<String[]> out=new ArrayList<>(); if(!Files.exists(f)) return out;
        try(BufferedReader r=Files.newBufferedReader(f)) {String line;
            while((line=r.readLine())!=null) {String[] x=parse(line); if(x!=null && Integer.parseInt(x[3])==route) out.add(x);} }
        return out;
    }
    public static void main(String[] args) throws Exception {
        Path f=Files.createTempFile("buspass-full", ".txt");
        add(f,new String[]{"P1","192572082","Anu|Sri","12","Poonamallee","2027-05-31","4500"});
        Files.writeString(f,"BAD|ROW\n",StandardOpenOption.APPEND);
        add(f,new String[]{"P2","192572083","Devi","7","Avadi","2027-05-31","3800"});
        System.out.println("Find P1: "+Arrays.toString(find(f,"P1")));
        System.out.println("Missing P9: "+Arrays.toString(find(f,"P9")));
        System.out.println("Route 12 count: "+route(f,12).size()); Files.delete(f);
    }
}

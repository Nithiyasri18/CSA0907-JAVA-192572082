import java.nio.file.*;
import java.sql.*;
import java.util.*;
public class PassMigration {
    public static void main(String[] args)throws Exception {
        if(args.length!=1){System.err.println("Usage: java PassMigration <seven-field-pass-file>");return;}
        Path file=Path.of(args[0]);List<String[]> good=new ArrayList<>();List<String> bad=new ArrayList<>();
        int lineNumber=0;for(String line:Files.readAllLines(file)){lineNumber++;
            String[] p=BusPassFileStore.parse(line);
            if(p==null){bad.add("line "+lineNumber+": "+line);continue;}
            good.add(new String[]{p[0],p[1],p[2],p[3],p[6]});}
        String url=System.getenv().getOrDefault("JDBC_URL","jdbc:mysql://localhost:3306/assignment5_test");
        try(Connection c=DriverManager.getConnection(url,System.getenv().getOrDefault("JDBC_USER","root"),System.getenv().getOrDefault("JDBC_PASSWORD",""))){
            DatabaseMetaData md=c.getMetaData();System.out.println("DB: "+md.getDatabaseProductName()+" "+md.getDatabaseProductVersion());
            System.out.println("Driver: "+md.getDriverName()+" "+md.getDriverVersion());
            try(ResultSet tables=md.getTables(null,null,"%",new String[]{"TABLE"})){while(tables.next())System.out.println("Table: "+tables.getString("TABLE_NAME"));}
            int loaded=PassLoader.loadAll(c,good);System.out.println("Imported: "+loaded);}
        Files.write(Path.of("migration_rejected.txt"),bad);
        System.out.println("Rejected: "+bad.size()+" (migration_rejected.txt)");
    }
}

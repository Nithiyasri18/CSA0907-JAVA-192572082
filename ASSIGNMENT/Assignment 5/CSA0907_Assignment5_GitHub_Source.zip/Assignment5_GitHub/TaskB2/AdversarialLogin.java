import java.sql.*;
public class AdversarialLogin {
    public static void main(String[] args)throws Exception {
        String url=System.getenv().getOrDefault("JDBC_URL","jdbc:mysql://localhost:3306/assignment5_test");
        String user=System.getenv().getOrDefault("JDBC_USER","root");
        String pwd=System.getenv().getOrDefault("JDBC_PASSWORD","");
        String id="student' -- "; String invalidPassword="wrong";
        try(Connection c=DriverManager.getConnection(url,user,pwd)){
            String unsafe="SELECT * FROM users WHERE id='"+id+"' AND pwd='"+invalidPassword+"'";
            try(Statement s=c.createStatement();ResultSet rs=s.executeQuery(unsafe)){
                System.out.println("Unsafe login accepted invalid password: "+rs.next());}
            try(PreparedStatement ps=c.prepareStatement("SELECT * FROM users WHERE id=? AND pwd=?")){
                ps.setString(1,id);ps.setString(2,invalidPassword);
                try(ResultSet rs=ps.executeQuery()){
                    System.out.println("Prepared login accepted invalid password: "+rs.next());}}
        }
    }
}

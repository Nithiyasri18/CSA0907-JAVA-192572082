import java.nio.file.*;
import java.util.*;
public class DamagedPassTest {
    public static void main(String[] args)throws Exception {
        Path p=Files.createTempFile("damaged", ".csv");try{
            Files.writeString(p,"P1,R1,Good,12,4500\nP2,R2,Wrong\nP3,R3,Invalid,7,not-number\n\nP4,R4,Valid,9,3800\n");
            PassStore s=new PassStore(p);
            for(String id:new String[]{"P1","P2","P3","P4","P9"})System.out.println(id+" -> "+Arrays.toString(s.find(id)));
        }finally{Files.deleteIfExists(p);}
    }
}

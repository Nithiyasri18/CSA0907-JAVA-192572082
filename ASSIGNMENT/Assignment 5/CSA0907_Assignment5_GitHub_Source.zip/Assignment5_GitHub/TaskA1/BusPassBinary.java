import java.io.*;
import java.nio.file.*;
public class BusPassBinary {
    public static void main(String[] args)throws Exception {
        Path p=Files.createTempFile("buspass", ".bin");
        try(DataOutputStream out=new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(p)))){
            out.writeUTF("P1001");out.writeUTF("192572082");out.writeUTF("Anu|Sri");
            out.writeInt(12);out.writeUTF("Poonamallee");out.writeUTF("2027-05-31");out.writeDouble(4500.0);
        }
        try(DataInputStream in=new DataInputStream(new BufferedInputStream(Files.newInputStream(p)))){
            System.out.printf("%s %s %s %d %s %s %.2f%n",in.readUTF(),in.readUTF(),in.readUTF(),in.readInt(),in.readUTF(),in.readUTF(),in.readDouble());
        }Files.delete(p);
    }
}

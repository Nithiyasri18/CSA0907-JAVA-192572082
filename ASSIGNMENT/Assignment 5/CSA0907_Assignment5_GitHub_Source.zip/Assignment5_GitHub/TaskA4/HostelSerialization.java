import java.io.*;
import java.util.*;
public class HostelSerialization {
    static class Resident implements Serializable {
        private static final long serialVersionUID=1L;
        String name, regNo, phone;
        transient String password;
        transient java.sql.Connection connection;
        Resident(String n,String r,String p){name=n;regNo=r;password=p;}
    }
    static class Room implements Serializable {private static final long serialVersionUID=1L;List<Resident> residents=new ArrayList<>();}
    static class Hostel implements Serializable {private static final long serialVersionUID=1L;List<Room> rooms=new ArrayList<>();}
    public static void main(String[] args)throws Exception {
        Hostel h=new Hostel();Room r=new Room();r.residents.add(new Resident("Divya","192311003","secret"));h.rooms.add(r);
        byte[] bytes;try(ByteArrayOutputStream b=new ByteArrayOutputStream();ObjectOutputStream o=new ObjectOutputStream(b)){o.writeObject(h);o.flush();bytes=b.toByteArray();}
        try(ObjectInputStream in=new ObjectInputStream(new ByteArrayInputStream(bytes))){Hostel loaded=(Hostel)in.readObject();Resident x=loaded.rooms.get(0).residents.get(0);
            System.out.println("Resident: "+x.name+", password after load: "+x.password+", connection: "+x.connection);}
    }
}

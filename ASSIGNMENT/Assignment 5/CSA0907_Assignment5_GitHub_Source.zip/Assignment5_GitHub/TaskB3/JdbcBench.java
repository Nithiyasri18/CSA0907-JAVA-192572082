import java.sql.*;
import java.util.*;
public class JdbcBench {
    static String url(){return System.getenv().getOrDefault("JDBC_URL","jdbc:mysql://localhost:3306/assignment5_test");}
    static Connection connect()throws SQLException{return DriverManager.getConnection(url(),System.getenv().getOrDefault("JDBC_USER","root"),System.getenv().getOrDefault("JDBC_PASSWORD",""));}
    static void clear(Connection c)throws SQLException {try(Statement s=c.createStatement()){s.executeUpdate("DELETE FROM bus_pass");}}
    static String[] pass(int i){return new String[]{"P"+i,"R"+i,"Student"+i,""+(i%30+1),""+(1000+i%500)};}
    static int insert(Connection c,int n,String mode)throws SQLException {
        String sql="INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES(?,?,?,?,?)";
        if(mode.equals("Statement")){try(Statement s=c.createStatement()){for(int i=0;i<n;i++){String[] p=pass(i);s.executeUpdate("INSERT INTO bus_pass VALUES('"+p[0]+"','"+p[1]+"','"+p[2]+"',"+p[3]+","+p[4]+")");}}return n;}
        if(mode.equals("Prepared")){try(PreparedStatement ps=c.prepareStatement(sql)){for(int i=0;i<n;i++){bind(ps,pass(i));ps.executeUpdate();}}return n;}
        List<String[]> list=new ArrayList<>();for(int i=0;i<n;i++)list.add(pass(i));return PassLoader.loadAll(c,list);
    }
    static void bind(PreparedStatement ps,String[] p)throws SQLException {ps.setString(1,p[0]);ps.setString(2,p[1]);ps.setString(3,p[2]);ps.setInt(4,Integer.parseInt(p[3]));ps.setDouble(5,Double.parseDouble(p[4]));}
    static void verify(Connection c,int expected)throws SQLException {try(Statement s=c.createStatement();ResultSet rs=s.executeQuery("SELECT * FROM bus_pass")){ResultSetMetaData m=rs.getMetaData();int rows=0;while(rs.next())rows++;if(rows!=expected)throw new AssertionError(rows+" != "+expected);System.out.print("columns=");for(int i=1;i<=m.getColumnCount();i++)System.out.print(m.getColumnName(i)+":"+m.getColumnTypeName(i)+" ");System.out.println();}}
    static void failureDemo(Connection c)throws SQLException {clear(c);List<String[]> rows=new ArrayList<>();for(int i=0;i<10;i++)rows.add(pass(i));rows.get(5)[4]="not-a-number";
        try{PassLoader.loadAll(c,rows);throw new AssertionError("Expected failure");}catch(NumberFormatException expected){System.out.println("Forced invalid amount rejected: "+expected.getMessage());}verify(c,0);}
    public static void main(String[] args)throws Exception {try(Connection c=connect()){
        System.out.println("mode,records,elapsed_ms");
        for(int n:new int[]{10,1000,10000,100000})for(String mode:new String[]{"Statement","Prepared","Batch"}){
            clear(c);long start=System.nanoTime();int count=insert(c,n,mode);double ms=(System.nanoTime()-start)/1e6;
            verify(c,count);System.out.printf(Locale.ROOT,"%s,%d,%.3f%n",mode,n,ms);}
        failureDemo(c);
    }}
}

CREATE DATABASE IF NOT EXISTS simats_fees;
USE simats_fees;
CREATE TABLE IF NOT EXISTS fees (
    id      BIGINT        NOT NULL AUTO_INCREMENT PRIMARY KEY,
    reg_no  VARCHAR(15)   NOT NULL,
    amount  DECIMAL(10,2) NOT NULL CHECK (amount > 0),
    paid_at TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_fees_reg_no (reg_no)
);

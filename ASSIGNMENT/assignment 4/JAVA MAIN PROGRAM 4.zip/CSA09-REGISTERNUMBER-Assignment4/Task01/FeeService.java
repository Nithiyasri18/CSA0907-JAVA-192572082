import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Optional;
import java.util.regex.Pattern;

/** Business logic of the fee module: validation, bank confirmation and persistence. */
public class FeeService {

    /** Supplies a fresh connection for every operation (keeps the service testable). */
    public interface ConnectionProvider { Connection get() throws SQLException; }

    /** Thrown when user input breaks a business rule; the message is safe to show. */
    public static class ValidationException extends Exception {
        public ValidationException(String message) { super(message); }
    }

    /** Immutable result of a successful payment or receipt lookup. */
    public record Receipt(long id, String regNo, BigDecimal amount, Timestamp paidAt) { }

    public static final BigDecimal MAX_AMOUNT = new BigDecimal("500000.00");
    private static final Pattern REG_NO = Pattern.compile("[A-Za-z0-9]{6,15}");

    private final ConnectionProvider provider;
    private final long bankDelayMillis;   // simulated bank-confirmation delay

    public FeeService(ConnectionProvider provider, long bankDelayMillis) {
        this.provider = provider;
        this.bankDelayMillis = bankDelayMillis;
    }

    /** Pure validation: no I/O, so it is cheap to call on the event-dispatch thread. */
    public static String validateRegNo(String regNo) throws ValidationException {
        String r = regNo == null ? "" : regNo.trim();
        if (r.isEmpty()) throw new ValidationException("Register number is required.");
        if (!REG_NO.matcher(r).matches())
            throw new ValidationException("Register number must be 6-15 letters or digits.");
        return r;
    }

    public static BigDecimal validateAmount(String amountText) throws ValidationException {
        String t = amountText == null ? "" : amountText.trim();
        if (t.isEmpty()) throw new ValidationException("Amount is required.");
        BigDecimal a;
        try {
            a = new BigDecimal(t);
        } catch (NumberFormatException ex) {
            throw new ValidationException("Amount must be a number, e.g. 12500.00.");
        }
        if (a.signum() <= 0) throw new ValidationException("Amount must be greater than zero.");
        if (a.scale() > 2) throw new ValidationException("Amount can have at most two decimal places.");
        if (a.compareTo(MAX_AMOUNT) > 0) throw new ValidationException("Amount exceeds the limit of " + MAX_AMOUNT + ".");
        return a;
    }

    /** Validates, simulates bank confirmation and records the payment. Call from a worker thread. */
    public Receipt pay(String regNo, String amountText)
            throws ValidationException, SQLException, InterruptedException {
        String reg = validateRegNo(regNo);
        BigDecimal amount = validateAmount(amountText);
        Thread.sleep(bankDelayMillis);                       // stands in for the bank call
        String sql = "INSERT INTO fees (reg_no, amount) VALUES (?, ?)";
        try (Connection con = provider.get()) {              // always closed, even on error
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, reg);
                ps.setBigDecimal(2, amount);
                ps.executeUpdate();
            }
            return findLatest(con, reg).orElseThrow(() -> new SQLException("Payment not found after insert."));
        }
    }

    /** Looks up the most recent receipt for a student. Call from a worker thread. */
    public Optional<Receipt> latestReceipt(String regNo) throws ValidationException, SQLException {
        String reg = validateRegNo(regNo);
        try (Connection con = provider.get()) {
            return findLatest(con, reg);
        }
    }

    private Optional<Receipt> findLatest(Connection con, String reg) throws SQLException {
        String sql = "SELECT id, reg_no, amount, paid_at FROM fees WHERE reg_no = ? ORDER BY id DESC LIMIT 1";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, reg);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next()
                    ? Optional.of(new Receipt(rs.getLong("id"), rs.getString("reg_no"),
                                              rs.getBigDecimal("amount"), rs.getTimestamp("paid_at")))
                    : Optional.empty();
            }
        }
    }
}

/** Console test of FeeService validation; needs no database and no GUI. */
public class FeeServiceValidationTest {
    private static int failures = 0;

    private static void expectOk(String label, String reg, String amt) {
        try {
            FeeService.validateRegNo(reg); FeeService.validateAmount(amt);
            System.out.println("PASS  " + label);
        } catch (FeeService.ValidationException e) {
            failures++; System.out.println("FAIL  " + label + " -> " + e.getMessage());
        }
    }

    private static void expectReject(String label, String reg, String amt, String expectedPart) {
        try {
            FeeService.validateRegNo(reg); FeeService.validateAmount(amt);
            failures++; System.out.println("FAIL  " + label + " -> accepted");
        } catch (FeeService.ValidationException e) {
            boolean ok = e.getMessage().contains(expectedPart);
            if (!ok) failures++;
            System.out.println((ok ? "PASS  " : "FAIL  ") + label + " -> " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        expectOk("valid input", "192572082", "12500.50");
        expectReject("empty register number", "  ", "100", "required");
        expectReject("bad register number", "12 34", "100", "6-15");
        expectReject("empty amount", "192572082", "", "required");
        expectReject("non-numeric amount", "192572082", "abc", "number");
        expectReject("zero amount", "192572082", "0", "greater than zero");
        expectReject("negative amount", "192572082", "-5", "greater than zero");
        expectReject("three decimals", "192572082", "10.123", "two decimal");
        expectReject("above limit", "192572082", "500000.01", "limit");
        expectReject("SQL text as reg no", "x'); DROP TABLE fees;--", "100", "6-15");
        System.out.println(failures == 0 ? "ALL TESTS PASSED" : failures + " TEST(S) FAILED");
        if (failures > 0) System.exit(1);
    }
}

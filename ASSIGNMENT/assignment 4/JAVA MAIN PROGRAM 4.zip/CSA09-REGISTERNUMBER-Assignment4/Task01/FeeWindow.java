import java.awt.*;
import java.awt.event.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import javax.swing.*;

/** User interface only: collects input, delegates to FeeService, shows results. */
public class FeeWindow extends JFrame {
    private final FeeService service;
    private final JTextField regNo = new JTextField(15);
    private final JTextField amount = new JTextField(15);
    private final JButton pay = new JButton("Pay");
    private final JButton clear = new JButton("Clear");
    private final JButton receipt = new JButton("Receipt");
    private final JLabel status = new JLabel("Enter the register number and amount.");
    private boolean busy = false;

    public FeeWindow(FeeService service) {
        super("Student Fee Payment");
        this.service = service;

        JPanel form = new JPanel(new GridLayout(2, 2, 6, 6));
        form.add(new JLabel("Register number:")); form.add(regNo);
        form.add(new JLabel("Amount (INR):"));    form.add(amount);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttons.add(pay); buttons.add(clear); buttons.add(receipt);

        JPanel root = new JPanel(new BorderLayout(8, 8));
        root.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        root.add(form, BorderLayout.NORTH);
        root.add(buttons, BorderLayout.CENTER);
        root.add(status, BorderLayout.SOUTH);
        setContentPane(root);

        pay.addActionListener(e -> onPay());          // one handler per button
        clear.addActionListener(e -> onClear());
        receipt.addActionListener(e -> onReceipt());

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE); // closing is decided in windowClosing
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { onClose(); }
        });
        pack();
        setLocationRelativeTo(null);
    }

    private void onPay() {
        try {                                           // fast, I/O-free checks on the EDT
            FeeService.validateRegNo(regNo.getText());
            FeeService.validateAmount(amount.getText());
        } catch (FeeService.ValidationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Invalid input", JOptionPane.WARNING_MESSAGE);
            return;
        }
        setBusy(true, "Processing payment...");
        final String reg = regNo.getText(), amt = amount.getText();
        new SwingWorker<FeeService.Receipt, Void>() {
            @Override protected FeeService.Receipt doInBackground() throws Exception {
                return service.pay(reg, amt);           // sleep + JDBC run off the EDT
            }
            @Override protected void done() {
                try {
                    FeeService.Receipt r = get();
                    setBusy(false, "Payment recorded (receipt no. " + r.id() + ").");
                    JOptionPane.showMessageDialog(FeeWindow.this, "Paid INR " + r.amount() + " for " + r.regNo());
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (ExecutionException ex) {
                    fail(ex.getCause());
                }
            }
        }.execute();
    }

    private void onReceipt() {
        setBusy(true, "Fetching receipt...");
        final String reg = regNo.getText();
        new SwingWorker<Optional<FeeService.Receipt>, Void>() {
            @Override protected Optional<FeeService.Receipt> doInBackground() throws Exception {
                return service.latestReceipt(reg);
            }
            @Override protected void done() {
                try {
                    Optional<FeeService.Receipt> r = get();
                    setBusy(false, r.isPresent() ? "Receipt loaded." : "No payment found.");
                    JOptionPane.showMessageDialog(FeeWindow.this,
                        r.map(x -> "Receipt " + x.id() + "\n" + x.regNo() + "\nINR " + x.amount() + "\n" + x.paidAt())
                         .orElse("No payment found for this register number."), "Receipt",
                        JOptionPane.INFORMATION_MESSAGE);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (ExecutionException ex) {
                    fail(ex.getCause());
                }
            }
        }.execute();
    }

    private void onClear() {
        regNo.setText(""); amount.setText("");
        status.setText("Fields cleared.");
        regNo.requestFocusInWindow();
    }

    private void onClose() {
        if (busy) {
            int c = JOptionPane.showConfirmDialog(this, "A payment is in progress. Close anyway?",
                    "Confirm exit", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (c != JOptionPane.YES_OPTION) return;
        }
        dispose();
        System.exit(0);
    }

    private void fail(Throwable cause) {
        setBusy(false, "Operation failed.");
        String msg = (cause instanceof FeeService.ValidationException) ? cause.getMessage()
                   : (cause instanceof SQLException) ? "Database error: " + cause.getMessage()
                   : "Unexpected error: " + cause;
        JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void setBusy(boolean b, String message) {
        busy = b;
        pay.setEnabled(!b); receipt.setEnabled(!b); clear.setEnabled(!b);
        status.setText(message);
    }

    public static void main(String[] args) {
        String url = System.getenv().getOrDefault("FEE_DB_URL", "jdbc:mysql://localhost:3306/simats_fees");
        String user = System.getenv().getOrDefault("FEE_DB_USER", "fee_app");
        String pwd = System.getenv().getOrDefault("FEE_DB_PASSWORD", "");
        FeeService service = new FeeService(() -> DriverManager.getConnection(url, user, pwd), 3000);
        SwingUtilities.invokeLater(() -> new FeeWindow(service).setVisible(true));
    }
}

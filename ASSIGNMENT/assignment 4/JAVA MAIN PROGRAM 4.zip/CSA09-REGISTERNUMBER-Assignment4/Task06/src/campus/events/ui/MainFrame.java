package campus.events.ui;

import campus.events.model.Event;
import campus.events.service.RegistrationService;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.swing.*;

/** Main window: menu bar plus a CardLayout holding the two screens. */
public class MainFrame extends JFrame {
    private static final String FORM = "form", COMMITTEE = "committee";
    private final CardLayout cards = new CardLayout();
    private final JPanel deck = new JPanel(cards);
    private final CommitteePanel committee;
    private final RegistrationPanel form;
    private final RegistrationService service;

    public MainFrame(RegistrationService service) {
        super("Campus Event Registration");
        this.service = service;
        committee = new CommitteePanel(service);
        form = new RegistrationPanel(service, committee::loadPage);
        deck.add(form, FORM);
        deck.add(committee, COMMITTEE);
        setContentPane(deck);
        setJMenuBar(buildMenu());

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { confirmExit(); }
        });
        setMinimumSize(new Dimension(640, 420));
        setSize(860, 520);
        setLocationRelativeTo(null);
        loadEvents();
    }

    private JMenuBar buildMenu() {
        JMenu file = new JMenu("File");
        JMenuItem export = new JMenuItem("Export CSV...");
        JMenuItem exit = new JMenuItem("Exit");
        export.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, KeyEvent.CTRL_DOWN_MASK));
        export.addActionListener(e -> { show(COMMITTEE); committee.exportCsv(); });
        exit.addActionListener(e -> confirmExit());
        file.add(export); file.addSeparator(); file.add(exit);

        JMenu view = new JMenu("View");
        JMenuItem register = new JMenuItem("Register Student");
        JMenuItem list = new JMenuItem("Committee View");
        JMenuItem refresh = new JMenuItem("Refresh");
        register.addActionListener(e -> show(FORM));
        list.addActionListener(e -> show(COMMITTEE));
        refresh.addActionListener(e -> committee.loadPage());
        view.add(register); view.add(list); view.addSeparator(); view.add(refresh);

        JMenu help = new JMenu("Help");
        JMenuItem about = new JMenuItem("About");
        about.addActionListener(e -> JOptionPane.showMessageDialog(this,
            "Campus Event Registration\nCSA09 Assignment 4 - Task 6", "About", JOptionPane.INFORMATION_MESSAGE));
        help.add(about);

        JMenuBar bar = new JMenuBar();
        bar.add(file); bar.add(view); bar.add(help);
        return bar;
    }

    private void show(String card) {
        cards.show(deck, card);
        if (COMMITTEE.equals(card)) committee.loadPage();
    }

    private void loadEvents() {
        new SwingWorker<List<Event>, Void>() {
            @Override protected List<Event> doInBackground() throws Exception { return service.loadEvents(); }
            @Override protected void done() {
                try {
                    List<Event> events = get();
                    form.setEvents(events);
                    committee.setEvents(events);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (ExecutionException ex) {
                    JOptionPane.showMessageDialog(MainFrame.this, "Cannot reach the database:\n"
                        + ex.getCause().getMessage(), "Connection error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    private void confirmExit() {
        int c = JOptionPane.showConfirmDialog(this, "Exit the application?", "Confirm exit",
                                              JOptionPane.YES_NO_OPTION);
        if (c == JOptionPane.YES_OPTION) { dispose(); System.exit(0); }
    }
}

package campus.events.model;

/** An event students can register for; id 0 is used by the UI for "All events". */
public record Event(int id, String title) {
    @Override public String toString() { return title; }
}

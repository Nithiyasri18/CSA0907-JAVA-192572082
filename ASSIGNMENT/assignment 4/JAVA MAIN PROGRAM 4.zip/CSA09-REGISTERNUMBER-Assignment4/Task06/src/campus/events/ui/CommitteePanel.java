package campus.events.ui;

import campus.events.model.Event;
import campus.events.model.PageResult;
import campus.events.model.RegistrationRow;
import campus.events.service.RegistrationService;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

/** Committee screen: filter, paged table and CSV export. All database work runs in SwingWorkers. */
class CommitteePanel extends JPanel {
    static final int PAGE_SIZE = 25;
    private final RegistrationService service;
    private final DefaultTableModel model = new DefaultTableModel(
        new String[]{"Reg ID", "Register No.", "Name", "Department", "Event", "Registered At"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JComboBox<Event> filter = new JComboBox<>();
    private final JButton refresh = new JButton("Refresh");
    private final JButton prev = new JButton("Prev");
    private final JButton next = new JButton("Next");
    private final JButton export = new JButton("Export CSV");
    private final JLabel info = new JLabel("No data loaded");
    private int page = 0;
    private long total = 0;
    private int requestId = 0;                 // used to ignore stale worker results

    CommitteePanel(RegistrationService service) {
        super(new BorderLayout(6, 6));
        this.service = service;
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        top.add(new JLabel("Event:"));
        top.add(filter);
        top.add(refresh);
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottom.add(prev); bottom.add(info); bottom.add(next); bottom.add(export);
        add(top, BorderLayout.NORTH);
        add(new JScrollPane(new JTable(model)), BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        filter.addActionListener(e -> { page = 0; loadPage(); });
        refresh.addActionListener(e -> loadPage());
        prev.addActionListener(e -> { page--; loadPage(); });
        next.addActionListener(e -> { page++; loadPage(); });
        export.addActionListener(e -> exportCsv());
    }

    void setEvents(List<Event> events) {
        filter.removeAllItems();
        filter.addItem(new Event(0, "All events"));      // adding the first item fires the filter listener
        events.forEach(filter::addItem);
    }

    private Integer selectedEventId() {
        Event ev = (Event) filter.getSelectedItem();
        return (ev == null || ev.id() == 0) ? null : ev.id();
    }

    void loadPage() {
        final int myRequest = ++requestId;
        final int myPage = page;
        final Integer eventId = selectedEventId();
        setBusy(true);
        new SwingWorker<PageResult, Void>() {
            @Override protected PageResult doInBackground() throws SQLException {
                return service.loadPage(eventId, myPage, PAGE_SIZE);   // LIMIT/OFFSET query
            }
            @Override protected void done() {
                if (myRequest != requestId) return;                    // a newer request superseded this one
                try {
                    PageResult r = get();
                    total = r.total();
                    model.setRowCount(0);
                    for (RegistrationRow row : r.rows())
                        model.addRow(new Object[]{row.id(), row.studentId(), row.name(),
                                                  row.department(), row.eventTitle(), row.registeredAt()});
                    long pages = Math.max(1, (total + PAGE_SIZE - 1) / PAGE_SIZE);
                    info.setText("Page " + (page + 1) + " of " + pages + " (" + total + " registrations)");
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (ExecutionException ex) {
                    info.setText("Load failed");
                    JOptionPane.showMessageDialog(CommitteePanel.this, "Could not load registrations:\n"
                        + ex.getCause().getMessage(), "Database error", JOptionPane.ERROR_MESSAGE);
                }
                setBusy(false);
            }
        }.execute();
    }

    private void setBusy(boolean busy) {
        refresh.setEnabled(!busy); filter.setEnabled(!busy); export.setEnabled(!busy);
        prev.setEnabled(!busy && page > 0);
        next.setEnabled(!busy && (long) (page + 1) * PAGE_SIZE < total);
        if (busy) info.setText("Loading...");
    }

    void exportCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("registrations.csv"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
        final Path path = chooser.getSelectedFile().toPath();
        if (Files.exists(path) && JOptionPane.showConfirmDialog(this, path.getFileName() + " exists. Overwrite?",
                "Confirm overwrite", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        final Integer eventId = selectedEventId();
        export.setEnabled(false);
        new SwingWorker<Long, Void>() {
            @Override protected Long doInBackground() throws SQLException, IOException {
                try (var w = Files.newBufferedWriter(path, StandardCharsets.UTF_8)) {
                    return service.exportCsv(eventId, w);               // streams rows, constant memory
                }
            }
            @Override protected void done() {
                export.setEnabled(true);
                try {
                    JOptionPane.showMessageDialog(CommitteePanel.this, "Exported " + get() + " registrations to\n"
                        + path, "Export complete", JOptionPane.INFORMATION_MESSAGE);
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (ExecutionException ex) {
                    JOptionPane.showMessageDialog(CommitteePanel.this, "Export failed:\n"
                        + ex.getCause().getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }
}

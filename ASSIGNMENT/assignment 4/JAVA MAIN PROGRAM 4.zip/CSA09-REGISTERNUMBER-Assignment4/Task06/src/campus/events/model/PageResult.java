package campus.events.model;

import java.util.List;

/** One page of rows plus the total number of matching registrations. */
public record PageResult(List<RegistrationRow> rows, long total) { }

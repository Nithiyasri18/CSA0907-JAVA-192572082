package campus.events.dao;

import campus.events.model.Event;
import campus.events.model.PageResult;
import campus.events.model.RegistrationRequest;
import campus.events.model.RegistrationRow;
import java.sql.SQLException;
import java.util.List;
import java.util.function.Consumer;

/** Data-access contract; the service layer depends only on this interface. */
public interface RegistrationRepository {
    List<Event> findEvents() throws SQLException;
    boolean exists(String studentId, int eventId) throws SQLException;
    /** Inserts student (upsert) and registration in one transaction; false if it is a duplicate. */
    boolean register(RegistrationRequest r) throws SQLException;
    /** eventId == null means all events. */
    PageResult findPage(Integer eventId, int limit, int offset) throws SQLException;
    /** Streams every matching row without holding them all in memory. */
    void forEach(Integer eventId, Consumer<RegistrationRow> consumer) throws SQLException;
}

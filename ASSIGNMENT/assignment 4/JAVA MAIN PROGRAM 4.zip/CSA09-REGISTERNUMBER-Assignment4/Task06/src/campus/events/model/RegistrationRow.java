package campus.events.model;

import java.sql.Timestamp;

/** One row of the committee table (registration joined with student and event). */
public record RegistrationRow(long id, String studentId, String name, String department,
                              String eventTitle, Timestamp registeredAt) { }

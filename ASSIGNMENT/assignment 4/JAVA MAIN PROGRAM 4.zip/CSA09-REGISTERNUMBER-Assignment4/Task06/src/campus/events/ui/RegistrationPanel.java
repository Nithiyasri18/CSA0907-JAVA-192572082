package campus.events.ui;

import campus.events.model.Event;
import campus.events.model.RegistrationRequest;
import campus.events.service.DuplicateRegistrationException;
import campus.events.service.RegistrationService;
import campus.events.service.ValidationException;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.swing.*;

/** Student registration screen: collects input, shows dialogs, delegates to the service. */
class RegistrationPanel extends JPanel {
    private final RegistrationService service;
    private final Runnable onRegistered;
    private final JTextField studentId = new JTextField(18);
    private final JTextField name = new JTextField(18);
    private final JTextField email = new JTextField(18);
    private final JComboBox<String> department =
        new JComboBox<>(RegistrationService.DEPARTMENTS.toArray(new String[0]));
    private final JComboBox<Integer> year = new JComboBox<>(new Integer[]{1, 2, 3, 4});
    private final JComboBox<Event> event = new JComboBox<>();
    private final JButton register = new JButton("Register");
    private final JButton clear = new JButton("Clear");
    private final JLabel status = new JLabel(" ");

    RegistrationPanel(RegistrationService service, Runnable onRegistered) {
        super(new GridBagLayout());
        this.service = service;
        this.onRegistered = onRegistered;
        addRow(0, "Register number:", studentId);
        addRow(1, "Name:", name);
        addRow(2, "E-mail:", email);
        addRow(3, "Department:", department);
        addRow(4, "Year of study:", year);
        addRow(5, "Event:", event);
        JPanel buttons = new JPanel();
        buttons.add(register);
        buttons.add(clear);
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 6; c.gridwidth = 2; c.insets = new Insets(10, 6, 4, 6);
        add(buttons, c);
        c.gridy = 7;
        add(status, c);

        register.addActionListener(e -> onRegister());
        clear.addActionListener(e -> clearForm());
    }

    private void addRow(int row, String label, java.awt.Component field) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = row; c.insets = new Insets(4, 6, 4, 6); c.anchor = GridBagConstraints.WEST;
        c.gridx = 0; add(new JLabel(label), c);
        c.gridx = 1; add(field, c);
    }

    void setEvents(List<Event> events) {
        event.removeAllItems();
        events.forEach(event::addItem);
    }

    private RegistrationRequest readForm() {
        Event ev = (Event) event.getSelectedItem();
        return new RegistrationRequest(studentId.getText(), name.getText(), email.getText(),
            (String) department.getSelectedItem(), (Integer) year.getSelectedItem(), ev == null ? 0 : ev.id());
    }

    private void onRegister() {
        final RegistrationRequest req;
        try {
            req = service.validate(readForm());                      // cheap, no I/O: safe on the EDT
        } catch (ValidationException ex) {
            JOptionPane.showMessageDialog(this, "Please correct the following:\n- "
                + String.join("\n- ", ex.getErrors()), "Invalid input", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int ok = JOptionPane.showConfirmDialog(this, "Register " + req.name() + " ("
            + req.studentId() + ") for " + event.getSelectedItem() + "?",
            "Confirm registration", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) return;

        register.setEnabled(false);
        status.setText("Saving registration...");
        new SwingWorker<Void, Void>() {
            @Override protected Void doInBackground() throws Exception {
                service.register(req);                               // JDBC runs off the EDT
                return null;
            }
            @Override protected void done() {
                register.setEnabled(true);
                try {
                    get();
                    status.setText("Registered " + req.studentId() + ".");
                    JOptionPane.showMessageDialog(RegistrationPanel.this, "Registration successful.",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
                    clearForm();
                    onRegistered.run();
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (ExecutionException ex) {
                    Throwable t = ex.getCause();
                    status.setText("Registration failed.");
                    String msg = t instanceof DuplicateRegistrationException ? t.getMessage()
                        : t instanceof ValidationException ? t.getMessage()
                        : t instanceof SQLException ? "Database error: " + t.getMessage()
                        : "Unexpected error: " + t;
                    JOptionPane.showMessageDialog(RegistrationPanel.this, msg,
                        t instanceof DuplicateRegistrationException ? "Duplicate registration" : "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    private void clearForm() {
        studentId.setText(""); name.setText(""); email.setText("");
        department.setSelectedIndex(0); year.setSelectedIndex(0);
        studentId.requestFocusInWindow();
    }
}

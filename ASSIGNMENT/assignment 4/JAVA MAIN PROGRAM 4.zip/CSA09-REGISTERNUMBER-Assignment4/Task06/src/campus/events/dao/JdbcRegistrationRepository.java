package campus.events.dao;

import campus.events.model.Event;
import campus.events.model.PageResult;
import campus.events.model.RegistrationRequest;
import campus.events.model.RegistrationRow;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** JDBC implementation: every statement is parameterised and every resource is closed. */
public class JdbcRegistrationRepository implements RegistrationRepository {

    private static final String SELECT_ROWS =
        "SELECT r.reg_id, s.student_id, s.name, s.department, e.title, r.registered_at "
      + "FROM registrations r JOIN students s ON s.student_id = r.student_id "
      + "JOIN events e ON e.event_id = r.event_id ";

    @Override public List<Event> findEvents() throws SQLException {
        List<Event> events = new ArrayList<>();
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT event_id, title FROM events ORDER BY event_date");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) events.add(new Event(rs.getInt(1), rs.getString(2)));
        }
        return events;
    }

    @Override public boolean exists(String studentId, int eventId) throws SQLException {
        String sql = "SELECT 1 FROM registrations WHERE student_id = ? AND event_id = ?";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, studentId);
            ps.setInt(2, eventId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    @Override public boolean register(RegistrationRequest r) throws SQLException {
        String upsert = "INSERT INTO students (student_id, name, email, department, year_of_study) "
            + "VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), "
            + "email = VALUES(email), department = VALUES(department), year_of_study = VALUES(year_of_study)";
        String insert = "INSERT INTO registrations (student_id, event_id) VALUES (?, ?)";
        try (Connection c = Database.getConnection()) {
            c.setAutoCommit(false);                          // both statements succeed or neither does
            try (PreparedStatement s = c.prepareStatement(upsert);
                 PreparedStatement g = c.prepareStatement(insert)) {
                s.setString(1, r.studentId()); s.setString(2, r.name()); s.setString(3, r.email());
                s.setString(4, r.department()); s.setInt(5, r.year());
                s.executeUpdate();
                g.setString(1, r.studentId()); g.setInt(2, r.eventId());
                g.executeUpdate();
                c.commit();
                return true;
            } catch (SQLException e) {
                c.rollback();
                if (e.getErrorCode() == 1062 && String.valueOf(e.getMessage()).contains("uk_student_event"))
                    return false;                            // UNIQUE constraint caught a duplicate
                throw e;
            }
        }
    }

    @Override public PageResult findPage(Integer eventId, int limit, int offset) throws SQLException {
        String where = eventId == null ? "" : "WHERE r.event_id = ? ";
        String countSql = "SELECT COUNT(*) FROM registrations r " + where;
        String pageSql = SELECT_ROWS + where + "ORDER BY r.reg_id LIMIT ? OFFSET ?";
        try (Connection c = Database.getConnection()) {
            long total;
            try (PreparedStatement ps = c.prepareStatement(countSql)) {
                if (eventId != null) ps.setInt(1, eventId);
                try (ResultSet rs = ps.executeQuery()) { rs.next(); total = rs.getLong(1); }
            }
            List<RegistrationRow> rows = new ArrayList<>();
            try (PreparedStatement ps = c.prepareStatement(pageSql)) {
                int i = 1;
                if (eventId != null) ps.setInt(i++, eventId);
                ps.setInt(i++, limit);
                ps.setInt(i, offset);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) rows.add(map(rs));
                }
            }
            return new PageResult(rows, total);
        }
    }

    @Override public void forEach(Integer eventId, Consumer<RegistrationRow> consumer) throws SQLException {
        String sql = SELECT_ROWS + (eventId == null ? "" : "WHERE r.event_id = ? ") + "ORDER BY r.reg_id";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setFetchSize(1000);                           // stream in chunks (useCursorFetch=true)
            if (eventId != null) ps.setInt(1, eventId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) consumer.accept(map(rs));
            }
        }
    }

    private static RegistrationRow map(ResultSet rs) throws SQLException {
        return new RegistrationRow(rs.getLong(1), rs.getString(2), rs.getString(3),
                                   rs.getString(4), rs.getString(5), rs.getTimestamp(6));
    }
}

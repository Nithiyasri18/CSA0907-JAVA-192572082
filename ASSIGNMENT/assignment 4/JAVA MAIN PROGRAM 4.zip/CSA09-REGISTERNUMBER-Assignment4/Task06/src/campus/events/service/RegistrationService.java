package campus.events.service;

import campus.events.dao.RegistrationRepository;
import campus.events.model.Event;
import campus.events.model.PageResult;
import campus.events.model.RegistrationRequest;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.io.Writer;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Business rules: validation, duplicate prevention, paging and CSV export. No Swing here. */
public class RegistrationService {
    public static final List<String> DEPARTMENTS = List.of("CSE", "ECE", "EEE", "MECH", "CIVIL", "AI&DS");
    private static final Pattern STUDENT_ID = Pattern.compile("[A-Za-z0-9]{6,15}");
    private static final Pattern NAME = Pattern.compile("[\\p{L} .'-]{2,60}");
    private static final Pattern EMAIL = Pattern.compile("[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+");

    private final RegistrationRepository repo;

    public RegistrationService(RegistrationRepository repo) { this.repo = repo; }

    /** Pure validation; returns the cleaned request or throws with all messages. */
    public RegistrationRequest validate(RegistrationRequest in) throws ValidationException {
        List<String> errors = new ArrayList<>();
        String id = in.studentId() == null ? "" : in.studentId().trim();
        String name = in.name() == null ? "" : in.name().trim();
        String email = in.email() == null ? "" : in.email().trim();
        if (!STUDENT_ID.matcher(id).matches()) errors.add("Register number must be 6-15 letters or digits.");
        if (!NAME.matcher(name).matches()) errors.add("Name must be 2-60 letters (spaces, . ' - allowed).");
        if (email.length() > 100 || !EMAIL.matcher(email).matches()) errors.add("Enter a valid e-mail address.");
        if (!DEPARTMENTS.contains(in.department())) errors.add("Select a department.");
        if (in.year() < 1 || in.year() > 4) errors.add("Year of study must be between 1 and 4.");
        if (in.eventId() <= 0) errors.add("Select an event.");
        if (!errors.isEmpty()) throw new ValidationException(errors);
        return new RegistrationRequest(id, name, email, in.department(), in.year(), in.eventId());
    }

    public void register(RegistrationRequest in)
            throws ValidationException, DuplicateRegistrationException, SQLException {
        RegistrationRequest r = validate(in);
        String msg = "Student " + r.studentId() + " is already registered for this event.";
        if (repo.exists(r.studentId(), r.eventId()))        // friendly early check
            throw new DuplicateRegistrationException(msg);
        if (!repo.register(r))                              // UNIQUE key is the final guard (race safe)
            throw new DuplicateRegistrationException(msg);
    }

    public List<Event> loadEvents() throws SQLException { return repo.findEvents(); }

    public PageResult loadPage(Integer eventId, int pageIndex, int pageSize) throws SQLException {
        return repo.findPage(eventId, pageSize, pageIndex * pageSize);
    }

    /** Streams all matching registrations to the writer as CSV; returns the number of data rows. */
    public long exportCsv(Integer eventId, Writer out) throws SQLException, IOException {
        long[] count = {0};
        out.write("Reg ID,Register Number,Name,Department,Event,Registered At\n");
        try {
            repo.forEach(eventId, row -> {
                try {
                    out.write(row.id() + "," + csv(row.studentId()) + "," + csv(row.name()) + ","
                        + csv(row.department()) + "," + csv(row.eventTitle()) + "," + row.registeredAt() + "\n");
                    count[0]++;
                } catch (IOException e) { throw new UncheckedIOException(e); }
            });
        } catch (UncheckedIOException e) { throw e.getCause(); }
        out.flush();
        return count[0];
    }

    static String csv(String s) {
        return (s.contains(",") || s.contains("\"") || s.contains("\n"))
            ? "\"" + s.replace("\"", "\"\"") + "\"" : s;
    }
}

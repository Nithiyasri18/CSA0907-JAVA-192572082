package campus.events.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Connection factory; settings come from environment variables, never from source code. */
public final class Database {
    private static final String URL = System.getenv().getOrDefault("CAMPUS_DB_URL",
        "jdbc:mysql://localhost:3306/campus_events?useSSL=false&allowPublicKeyRetrieval=true&useCursorFetch=true");
    private static final String USER = System.getenv().getOrDefault("CAMPUS_DB_USER", "campus_app");
    private static final String PASSWORD = System.getenv().getOrDefault("CAMPUS_DB_PASSWORD", "ChangeMe#123");

    private Database() { }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}

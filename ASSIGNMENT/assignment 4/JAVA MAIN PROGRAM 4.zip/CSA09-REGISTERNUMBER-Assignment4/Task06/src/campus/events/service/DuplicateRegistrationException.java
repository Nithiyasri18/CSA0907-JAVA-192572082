package campus.events.service;

/** The student is already registered for the chosen event. */
public class DuplicateRegistrationException extends Exception {
    public DuplicateRegistrationException(String message) { super(message); }
}

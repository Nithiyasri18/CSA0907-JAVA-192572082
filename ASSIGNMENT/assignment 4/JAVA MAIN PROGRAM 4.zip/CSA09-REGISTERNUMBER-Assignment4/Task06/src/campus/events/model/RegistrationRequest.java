package campus.events.model;

/** Data entered on the registration form. */
public record RegistrationRequest(String studentId, String name, String email,
                                  String department, int year, int eventId) { }

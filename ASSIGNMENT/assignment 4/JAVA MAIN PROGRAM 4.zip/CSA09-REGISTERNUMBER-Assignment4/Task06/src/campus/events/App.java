package campus.events;

import campus.events.dao.JdbcRegistrationRepository;
import campus.events.service.RegistrationService;
import campus.events.ui.MainFrame;
import javax.swing.SwingUtilities;

/** Entry point: wires the three layers together and starts the UI on the EDT. */
public class App {
    public static void main(String[] args) {
        RegistrationService service = new RegistrationService(new JdbcRegistrationRepository());
        SwingUtilities.invokeLater(() -> new MainFrame(service).setVisible(true));
    }
}

@echo off
cd /d "%~dp0"
if exist out rmdir /s /q out
mkdir out
dir /s /b src\*.java > sources.txt
javac -d out @sources.txt test\ServiceSmokeTest.java
del sources.txt
echo Task06 compiled into Task06\out

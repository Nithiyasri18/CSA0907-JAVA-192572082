-- Campus Event Registration: schema and sample data (MySQL 8.0+)
CREATE DATABASE IF NOT EXISTS campus_events
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE campus_events;

-- Least-privilege account used by the application (change the password!)
CREATE USER IF NOT EXISTS 'campus_app'@'localhost' IDENTIFIED BY 'ChangeMe#123';
GRANT SELECT, INSERT, UPDATE ON campus_events.* TO 'campus_app'@'localhost';

CREATE TABLE IF NOT EXISTS students (
    student_id    VARCHAR(15)  NOT NULL,
    name          VARCHAR(60)  NOT NULL,
    email         VARCHAR(100) NOT NULL,
    department    VARCHAR(40)  NOT NULL,
    year_of_study TINYINT      NOT NULL,
    PRIMARY KEY (student_id),
    CONSTRAINT chk_year CHECK (year_of_study BETWEEN 1 AND 4)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS events (
    event_id   INT          NOT NULL AUTO_INCREMENT,
    title      VARCHAR(80)  NOT NULL,
    venue      VARCHAR(60)  NOT NULL,
    event_date DATE         NOT NULL,
    PRIMARY KEY (event_id),
    UNIQUE KEY uk_event_title_date (title, event_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS registrations (
    reg_id        BIGINT      NOT NULL AUTO_INCREMENT,
    student_id    VARCHAR(15) NOT NULL,
    event_id      INT         NOT NULL,
    registered_at TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (reg_id),
    -- one registration per student per event, enforced by the database itself
    UNIQUE KEY uk_student_event (student_id, event_id),
    -- supports "WHERE event_id = ? ORDER BY reg_id LIMIT ? OFFSET ?"
    KEY idx_reg_event_regid (event_id, reg_id),
    CONSTRAINT fk_reg_student FOREIGN KEY (student_id) REFERENCES students (student_id),
    CONSTRAINT fk_reg_event   FOREIGN KEY (event_id)   REFERENCES events (event_id)
) ENGINE=InnoDB;

INSERT INTO events (title, venue, event_date) VALUES
  ('Cultural Night',        'Main Auditorium', '2026-12-05'),
  ('Inter-Department Quiz', 'Seminar Hall A',  '2026-12-08'),
  ('Dance Competition',     'Open Air Theatre','2026-12-12'),
  ('Music Fest',            'Main Auditorium', '2026-12-15'),
  ('Poster Making',         'Art Gallery',     '2026-12-18');

INSERT INTO students (student_id, name, email, department, year_of_study) VALUES
  ('192500001', 'Asha Raman',   'asha@example.edu',   'CSE',    2),
  ('192500002', 'Bala Kumar',   'bala@example.edu',   'ECE',    3),
  ('192500003', 'Charu Nair',   'charu@example.edu',  'AI&DS',  1);

INSERT INTO registrations (student_id, event_id) VALUES
  ('192500001', 1), ('192500001', 2), ('192500002', 1), ('192500003', 3);

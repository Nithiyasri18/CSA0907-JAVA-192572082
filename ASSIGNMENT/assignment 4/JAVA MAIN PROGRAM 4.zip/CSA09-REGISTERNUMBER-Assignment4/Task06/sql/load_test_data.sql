-- Generates 20,000 students x 5 events = 100,000 registrations for the large-load test.
USE campus_events;
SET SESSION cte_max_recursion_depth = 20000;

INSERT INTO students (student_id, name, email, department, year_of_study)
WITH RECURSIVE seq (n) AS (
    SELECT 1 UNION ALL SELECT n + 1 FROM seq WHERE n < 20000
)
SELECT CONCAT('LT', LPAD(n, 6, '0')), CONCAT('Load Test Student ', n),
       CONCAT('lt', n, '@example.edu'),
       ELT(1 + MOD(n, 4), 'CSE', 'ECE', 'MECH', 'AI&DS'), 1 + MOD(n, 4)
FROM seq;

INSERT INTO registrations (student_id, event_id)
SELECT s.student_id, e.event_id
FROM students s CROSS JOIN events e
WHERE s.student_id LIKE 'LT%'
ORDER BY s.student_id, e.event_id;

SELECT COUNT(*) AS total_registrations FROM registrations;

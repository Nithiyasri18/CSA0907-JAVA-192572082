Copy mysql-connector-j-<version>.jar here (download from dev.mysql.com/downloads/connector/j/).

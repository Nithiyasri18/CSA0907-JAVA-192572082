#!/bin/bash
# Needs MySQL running with sql/schema.sql applied and the Connector/J jar in lib/
cd "$(dirname "$0")"
ls lib/*.jar >/dev/null 2>&1 || { echo "Put mysql-connector-j-<version>.jar into Task06/lib/ first"; exit 1; }
java -cp "out:lib/*" campus.events.App

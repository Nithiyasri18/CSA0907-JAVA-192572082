import campus.events.dao.RegistrationRepository;
import campus.events.model.Event;
import campus.events.model.PageResult;
import campus.events.model.RegistrationRequest;
import campus.events.model.RegistrationRow;
import campus.events.service.DuplicateRegistrationException;
import campus.events.service.RegistrationService;
import campus.events.service.ValidationException;
import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/** Runs the service layer against an in-memory repository (no MySQL, no GUI). */
public class ServiceSmokeTest {
    static class FakeRepo implements RegistrationRepository {
        final Set<String> keys = new HashSet<>();
        final List<RegistrationRow> rows = new ArrayList<>();
        public List<Event> findEvents() { return List.of(new Event(1, "Cultural Night")); }
        public boolean exists(String s, int e) { return keys.contains(s + "|" + e); }
        public boolean register(RegistrationRequest r) {
            if (!keys.add(r.studentId() + "|" + r.eventId())) return false;
            rows.add(new RegistrationRow(rows.size() + 1, r.studentId(), r.name(), r.department(),
                     "Cultural Night", new Timestamp(0)));
            return true;
        }
        public PageResult findPage(Integer ev, int limit, int offset) {
            int to = Math.min(rows.size(), offset + limit);
            return new PageResult(offset >= rows.size() ? List.of() : rows.subList(offset, to), rows.size());
        }
        public void forEach(Integer ev, Consumer<RegistrationRow> c) { rows.forEach(c); }
    }

    static int failures = 0;
    static void check(String label, boolean ok) {
        if (!ok) failures++;
        System.out.println((ok ? "PASS  " : "FAIL  ") + label);
    }

    public static void main(String[] args) throws Exception {
        FakeRepo repo = new FakeRepo();
        RegistrationService svc = new RegistrationService(repo);
        RegistrationRequest good = new RegistrationRequest("192572082", "Nithiya", "n@example.edu", "CSE", 2, 1);

        svc.register(good);
        check("successful registration stored", repo.rows.size() == 1);

        try { svc.register(good); check("duplicate rejected", false); }
        catch (DuplicateRegistrationException e) { check("duplicate rejected: " + e.getMessage(), true); }

        try {
            svc.register(new RegistrationRequest("12", "", "bad", "XYZ", 9, 0));
            check("invalid input rejected", false);
        } catch (ValidationException e) {
            check("invalid input rejected with " + e.getErrors().size() + " messages", e.getErrors().size() == 6);
            e.getErrors().forEach(m -> System.out.println("        - " + m));
        }
        check("nothing stored for invalid input", repo.rows.size() == 1);

        StringWriter sw = new StringWriter();
        long n = svc.exportCsv(null, sw);
        check("CSV export wrote " + n + " data row(s)", n == 1 && sw.toString().startsWith("Reg ID,"));
        check("paging returns total", svc.loadPage(null, 0, 25).total() == 1);
        System.out.println(failures == 0 ? "ALL TESTS PASSED" : failures + " TEST(S) FAILED");
        if (failures > 0) System.exit(1);
    }
}

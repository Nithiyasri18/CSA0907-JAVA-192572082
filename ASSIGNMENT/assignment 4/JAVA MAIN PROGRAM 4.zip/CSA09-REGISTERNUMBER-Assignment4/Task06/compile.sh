#!/bin/bash
cd "$(dirname "$0")"
rm -rf out && mkdir out
javac -d out $(find src -name '*.java') test/ServiceSmokeTest.java
echo "Task06 compiled into Task06/out"

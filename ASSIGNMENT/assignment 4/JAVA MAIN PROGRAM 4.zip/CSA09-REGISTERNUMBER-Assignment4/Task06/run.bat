@echo off
cd /d "%~dp0"
if not exist lib\*.jar (echo Put mysql-connector-j-VERSION.jar into Task06\lib first & exit /b 1)
java -cp "out;lib\*" campus.events.App

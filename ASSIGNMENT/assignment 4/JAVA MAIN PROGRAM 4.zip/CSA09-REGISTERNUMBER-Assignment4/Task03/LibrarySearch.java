import java.awt.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.*;

/** Campus library search screen built from nested BorderLayout and FlowLayout panels. */
public class LibrarySearch extends JFrame {
    private record Book(String title, String author, String category) { }

    private static final int PAGE_SIZE = 4;
    private static final List<Book> CATALOGUE = List.of(
        new Book("Introduction to Algorithms", "Cormen", "Computer Science"),
        new Book("Effective Java", "Bloch", "Computer Science"),
        new Book("Java: The Complete Reference", "Schildt", "Computer Science"),
        new Book("Database System Concepts", "Silberschatz", "Computer Science"),
        new Book("Operating System Concepts", "Galvin", "Computer Science"),
        new Book("Linear Algebra and Its Applications", "Strang", "Mathematics"),
        new Book("Discrete Mathematics", "Rosen", "Mathematics"),
        new Book("Probability and Statistics", "DeGroot", "Mathematics"),
        new Book("Fundamentals of Physics", "Halliday", "Physics"),
        new Book("Concepts of Modern Physics", "Beiser", "Physics"),
        new Book("Wings of Fire", "Kalam", "Literature"),
        new Book("The Guide", "Narayan", "Literature"));

    private final JTextField searchField = new JTextField(20);
    private final JComboBox<String> category =
        new JComboBox<>(new String[]{"All", "Computer Science", "Mathematics", "Physics", "Literature"});
    private final JButton searchButton = new JButton("Search");
    private final JButton prevButton = new JButton("Prev");
    private final JButton nextButton = new JButton("Next");
    private final JButton reserveButton = new JButton("Reserve");
    private final DefaultListModel<String> listModel = new DefaultListModel<>();
    private final JList<String> results = new JList<>(listModel);
    private final JLabel status = new JLabel("Enter a search term and press Search.");

    private final List<Book> matches = new ArrayList<>();
    private final Set<String> reserved = new HashSet<>();
    private int page = 0;

    public LibrarySearch() {
        super("Campus Library Search");

        // Header: BorderLayout -> title (NORTH) and search row (CENTER)
        JLabel title = new JLabel("Campus Library Search", SwingConstants.CENTER);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 20f));
        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 4));
        searchRow.add(new JLabel("Search:"));
        searchRow.add(searchField);
        searchRow.add(category);
        searchRow.add(searchButton);
        JPanel header = new JPanel(new BorderLayout());
        header.add(title, BorderLayout.NORTH);
        header.add(searchRow, BorderLayout.CENTER);

        // Footer: BorderLayout -> button row (CENTER) and status message (SOUTH)
        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 4));
        buttonRow.add(prevButton);
        buttonRow.add(nextButton);
        buttonRow.add(reserveButton);
        JPanel footer = new JPanel(new BorderLayout());
        footer.add(buttonRow, BorderLayout.CENTER);
        footer.add(status, BorderLayout.SOUTH);

        results.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane resultsPane = new JScrollPane(results);

        // Root: BorderLayout -> only CENTER grows when the window is resized
        JPanel root = new JPanel(new BorderLayout(6, 6));
        root.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        root.add(header, BorderLayout.NORTH);
        root.add(resultsPane, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        setContentPane(root);

        // Event handling: one listener serves both the Search button and the Enter key
        searchButton.addActionListener(e -> search());
        searchField.addActionListener(e -> search());
        prevButton.addActionListener(e -> { page--; showPage(); });
        nextButton.addActionListener(e -> { page++; showPage(); });
        reserveButton.addActionListener(e -> reserveSelected());
        results.addListSelectionListener(e -> updateButtons());

        updateButtons();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(560, 320));
        setSize(640, 420);
        setLocationRelativeTo(null);
    }

    private void search() {
        String q = searchField.getText().trim().toLowerCase();
        String cat = (String) category.getSelectedItem();
        matches.clear();
        for (Book b : CATALOGUE) {
            boolean text = q.isEmpty() || b.title().toLowerCase().contains(q)
                                       || b.author().toLowerCase().contains(q);
            boolean inCategory = "All".equals(cat) || b.category().equals(cat);
            if (text && inCategory) matches.add(b);
        }
        page = 0;
        showPage();
    }

    private void showPage() {
        listModel.clear();
        int from = page * PAGE_SIZE, to = Math.min(from + PAGE_SIZE, matches.size());
        for (int i = from; i < to; i++) {
            Book b = matches.get(i);
            listModel.addElement(b.title() + " - " + b.author() + " [" + b.category() + "]"
                                 + (reserved.contains(b.title()) ? "  (reserved)" : ""));
        }
        int pages = Math.max(1, (matches.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        status.setText(matches.isEmpty() ? "No books found."
            : matches.size() + " result(s). Page " + (page + 1) + " of " + pages + ".");
        updateButtons();
    }

    private void reserveSelected() {
        int i = results.getSelectedIndex();
        if (i < 0) { status.setText("Select a book first."); return; }
        Book b = matches.get(page * PAGE_SIZE + i);
        status.setText(reserved.add(b.title()) ? "Reserved: " + b.title()
                                               : "Already reserved: " + b.title());
        int keep = i;
        showPage();
        results.setSelectedIndex(keep);
    }

    private void updateButtons() {
        prevButton.setEnabled(page > 0);
        nextButton.setEnabled((page + 1) * PAGE_SIZE < matches.size());
        reserveButton.setEnabled(results.getSelectedIndex() >= 0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibrarySearch().setVisible(true));
    }
}

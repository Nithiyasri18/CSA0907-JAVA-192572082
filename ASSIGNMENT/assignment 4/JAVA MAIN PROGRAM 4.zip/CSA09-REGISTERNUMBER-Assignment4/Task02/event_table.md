# Task 2.1 – Event table (Hospital Outpatient Appointment Desk)

| Event source | Event object | Listener interface | Action performed |
|---|---|---|---|
| JFrame (window shown) | WindowEvent WINDOW_OPENED | WindowListener.windowOpened (WindowAdapter) | Load departments and doctor map in background; focus patient ID |
| patientId JTextField (Enter) | ActionEvent | ActionListener | Validate format; focus department |
| department JComboBox | ItemEvent (SELECTED) | ItemListener | Refresh doctor list from the map; clear slots |
| doctor JComboBox | ItemEvent (SELECTED) | ItemListener | Load free slots of the doctor |
| slot JComboBox | ActionEvent | ActionListener | Remember slot; enable Book |
| book JButton | ActionEvent | ActionListener | Validate; book in background; confirmation or error |
| clear JButton | ActionEvent | ActionListener | Reset fields |
| SwingWorker (finished) | done() / state PropertyChangeEvent | done() / PropertyChangeListener | Show result; clear bookingInProgress |
| JFrame (iconified/restored) | WindowEvent | WindowListener | No business action |
| JFrame (close button) | WindowEvent WINDOW_CLOSING | WindowListener.windowClosing | Confirm if booking in progress |
| JFrame (disposed) | WindowEvent WINDOW_CLOSED | WindowListener.windowClosed | Release resources |

Component hierarchy, diagrams and the full analysis are in the report (Task 2).

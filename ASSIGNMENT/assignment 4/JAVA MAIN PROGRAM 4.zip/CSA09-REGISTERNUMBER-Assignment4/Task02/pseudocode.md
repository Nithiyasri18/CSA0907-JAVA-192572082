# Task 2.3 – Handler pseudocode

## A. Refresh the doctor list
```
ALGORITHM RefreshDoctorList
INPUT  : e, an ItemEvent from departmentCombo
         doctorsByDept, a Map<String, List<Doctor>> loaded at start-up
OUTPUT : doctorCombo re-populated, slotCombo cleared, status updated
BEGIN
  1. IF e.getStateChange() is not SELECTED THEN RETURN     // ignore the DESELECTED half
  2. IF updating THEN RETURN
  3. updating <- true
  4. dept <- departmentCombo.getSelectedItem()
  5. doctorCombo.removeAllItems();  slotCombo.removeAllItems()
  6. bookButton.setEnabled(false)
  7. IF dept is null OR dept = "-- Select department --" THEN
        doctorCombo.setEnabled(false);  slotCombo.setEnabled(false)
        status <- "Select a department."
        updating <- false;  RETURN
  8. list <- doctorsByDept.get(dept)
  9. IF list is null OR list is empty THEN
        doctorCombo.setEnabled(false)
        status <- "No doctors available in " + dept
        updating <- false;  RETURN
 10. FOR EACH doctor IN list DO
        doctorCombo.addItem(doctor)
 11. doctorCombo.setEnabled(true)
 12. updating <- false
 13. doctorCombo.setSelectedIndex(0)          // fires the doctor handler, which loads slots
 14. status <- size(list) + " doctor(s) available in " + dept
END
```

## B. Validate and book
```
ALGORITHM ValidateAndBook
INPUT  : patientIdField, departmentCombo, doctorCombo, slotCombo, flag bookingInProgress
OUTPUT : confirmation or error message; one appointment row saved on success
BEGIN
  1. IF bookingInProgress THEN RETURN                       // ignore double clicks
  2. id <- trim(patientIdField.getText());  errors <- empty list
  3. IF id is empty THEN add "Patient ID is required" to errors
     ELSE IF id does not match [A-Z0-9]{4,12} THEN add "Patient ID format is invalid" to errors
  4. IF department is not selected THEN add "Select a department" to errors
  5. IF doctorCombo.getSelectedItem() is null THEN add "Select a doctor" to errors
  6. IF slotCombo.getSelectedItem() is null THEN add "Select a time slot" to errors
  7. IF errors is not empty THEN
        show error dialog listing all messages;  focus the first invalid field;  RETURN
  8. bookingInProgress <- true;  bookButton.setEnabled(false);  status <- "Booking..."
  9. START background task (SwingWorker.doInBackground):
        TRY
           IF patient id does not exist in the database THEN THROW PatientNotFound
           IF slot is already booked for this doctor THEN THROW SlotTaken
           INSERT appointment(patient, doctor, slot) using a parameterised statement
           result <- SUCCESS(appointment number)
        CATCH PatientNotFound, SlotTaken  -> result <- FAILURE(business message)
        CATCH SQLException                -> result <- FAILURE("Database error; try again")
 10. WHEN the task completes (SwingWorker.done, on the EDT):
        bookingInProgress <- false;  bookButton.setEnabled(true)
        IF result is SUCCESS THEN
           show confirmation (appointment number, doctor, slot);  remove the slot from slotCombo
           clear patientIdField;  status <- "Appointment booked."
        ELSE
           show error dialog with result.message;  keep the typed values so the user can correct them
           status <- "Booking failed."
END
```

# CSA09 – Programming in Java – Assignment 4 (CO4): Event-Driven GUI Design

- **Student name:** [Enter Name]
- **Register number:** [Enter Register Number]
- **Course / institution:** CSA09 Programming in Java, SIMATS Engineering
- **Java version:** Java 17 or later (written and compiled with OpenJDK 21)

## Project overview
Six tasks on event-driven GUI design with AWT/Swing and JDBC. Every folder holds the
source code, input/SQL files and a `screenshots/` folder with the output screenshots.

## Compile and run
Compile everything (no database needed):   ./compile_all.sh      (Windows: compile_all.bat)
Run one program from its folder, for example:
  Task01: java -cp out FeeWindow          (needs MySQL + driver, see Task01/fees.sql)
  Task03: java -cp out LibrarySearch
  Task04: java -cp out DrawPad            (in repaired/ or CompleteTheCode/)
  Task05: java -cp out Converter          (in each v1/... v2/... folder)
  Task06: cd Task06 && ./compile.sh && ./run.sh

## Tasks and results (fill in after running)
| Task | Folder | What it contains | Result |
|------|--------|------------------|--------|
| 1 | Task01 | FeeService + FeeWindow (repair of the poor design) | ... |
| 2 | Task02 | Event table, hierarchy, pseudocode (design task, no code) | ... |
| 3 | Task03 | LibrarySearch (nested BorderLayout/FlowLayout) | ... |
| 4 | Task04 | buggy, naive_fixed, repaired, CompleteTheCode, experiments | ... |
| 5 | Task05 | v1 (four styles), v2 (changed requirement), CompleteTheCode | ... |
| 6 | Task06 | Campus Event Registration (Swing + JDBC + MySQL) | ... |

## Task 6 – MySQL setup
1. Install MySQL Server 8.0 and Java 17+.
2. mysql -u root -p < Task06/sql/schema.sql   (change the account password in the script first)
3. Download MySQL Connector/J and copy the jar into Task06/lib/
4. Optional environment variables: CAMPUS_DB_URL, CAMPUS_DB_USER, CAMPUS_DB_PASSWORD
5. cd Task06 && ./compile.sh && ./run.sh
6. Large-load test only: mysql -u root -p < Task06/sql/load_test_data.sql

## Commits
At least one genuine, progressive commit per task (for example: "Task 1: add FeeService and FeeWindow").

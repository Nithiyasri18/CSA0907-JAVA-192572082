#!/bin/bash
# Compiles every program of the assignment into an out/ folder next to its sources.
# No database or MySQL driver is needed to compile.
set -e
cd "$(dirname "$0")"
c() { dir="$1"; shift; echo "== $dir"; mkdir -p "$dir/out"; javac -d "$dir/out" "$@"; }
c Task01 Task01/*.java
c Task03 Task03/*.java
for d in buggy naive_fixed repaired CompleteTheCode experiment_without_override; do c Task04/$d Task04/$d/DrawPad.java; done
echo "== Task04/experiment_with_override (a compile error is EXPECTED here)"
mkdir -p Task04/experiment_with_override/out
javac -d Task04/experiment_with_override/out Task04/experiment_with_override/DrawPad.java || echo "(expected error shown above)"
for v in v1 v2; do for d in A_FrameImplements B_NamedInner C_Anonymous D_Lambda; do c Task05/$v/$d Task05/$v/$d/Converter.java; done; done
c Task05/CompleteTheCode Task05/CompleteTheCode/Converter.java
echo "== Task06"; (cd Task06 && ./compile.sh)
echo "All programs compiled."

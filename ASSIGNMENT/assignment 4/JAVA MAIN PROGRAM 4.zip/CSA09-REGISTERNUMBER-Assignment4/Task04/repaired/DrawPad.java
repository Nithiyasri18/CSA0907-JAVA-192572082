import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

/** Repaired version of the original DrawPad: model (points) is separated from drawing. */
public class DrawPad extends Frame {
    private int count = 0;
    private final Label status = new Label("Clicks: 0");
    private final ArrayList<Point> points = new ArrayList<>();   // the drawing model

    public DrawPad() {
        super("Draw Pad (repaired)");
        add(status, BorderLayout.SOUTH);
        addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {   // correct name, checked by @Override
                points.add(e.getPoint());                        // 1. store the point
                count++;                                         // 2. update the counter
                status.setText("Clicks: " + count);              // 3. update the label
                repaint();                                       // 4. ask AWT to call paint()
            }
        });
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });
        setSize(400, 300);
    }

    @Override public void paint(Graphics g) {
        super.paint(g);                                          // paint the frame's children first
        for (Point p : points)                                   // redraw the whole model every time
            g.fillOval(p.x - 3, p.y - 3, 6, 6);                  // 6 x 6 dot centred on the click
    }

    public static void main(String[] args) { new DrawPad().setVisible(true); }
}

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class DrawPad extends Frame {
    int count = 0;
    Label status = new Label("Clicks: 0");

    public DrawPad() {
        add(status, BorderLayout.SOUTH);
        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {      // name fixed, but still draws with getGraphics()
                count++; status.setText("Clicks: " + count);
                Graphics g = getGraphics();
                g.fillOval(e.getX(), e.getY(), 6, 6);
            }
        });
        setSize(400, 300);
        setVisible(true);
    }

    public static void main(String[] args) { new DrawPad(); }
}

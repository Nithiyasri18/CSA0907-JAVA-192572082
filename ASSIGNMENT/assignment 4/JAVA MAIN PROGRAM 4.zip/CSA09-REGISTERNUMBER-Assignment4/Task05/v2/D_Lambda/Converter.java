import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Converter extends JFrame {
    private final JTextField amount = new JTextField(10);
    private final JComboBox<String> target = new JComboBox<>(new String[]{"USD", "EUR"});
    private final JLabel result = new JLabel(" ");

    /** Illustrative rates taken from the assignment code; NOT live market rates. */
    private static double rate(String currency) {
        return currency.equals("USD") ? 0.012 : 0.011;
    }

    public Converter() {
        super("Currency Converter");
        setLayout(new FlowLayout());
        JButton convertButton = new JButton("Convert");
        add(new JLabel("INR")); add(amount); add(target);
        add(convertButton); add(result);
        ActionListener convert = e -> {
            try {
                double inr = Double.parseDouble(amount.getText().trim());
                if (!(inr >= 0) || Double.isInfinite(inr)) throw new NumberFormatException();
                String cur = (String) target.getSelectedItem();
                String msg = String.format("%.2f %s", inr * rate(cur), cur);
                result.setText(msg);
                JOptionPane.showMessageDialog(this, msg);
            } catch (NumberFormatException ex) {
                String msg = "Invalid amount";
                result.setText(msg);
                JOptionPane.showMessageDialog(this, msg, "Error", JOptionPane.ERROR_MESSAGE);
            }
        };
        convertButton.addActionListener(convert);
        amount.addActionListener(convert);              // Enter key
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); System.exit(0); }
        });
        pack();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Converter().setVisible(true));
    }
}

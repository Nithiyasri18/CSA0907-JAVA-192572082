@echo off
rem Compiles every program of the assignment (no database needed to compile).
cd /d "%~dp0"
for %%D in (Task01 Task03) do (mkdir %%D\out 2>nul & javac -d %%D\out %%D\*.java)
for %%D in (buggy naive_fixed repaired CompleteTheCode experiment_without_override) do (mkdir Task04\%%D\out 2>nul & javac -d Task04\%%D\out Task04\%%D\DrawPad.java)
echo Task04\experiment_with_override: a compile error is EXPECTED
mkdir Task04\experiment_with_override\out 2>nul
javac -d Task04\experiment_with_override\out Task04\experiment_with_override\DrawPad.java
for %%V in (v1 v2) do for %%D in (A_FrameImplements B_NamedInner C_Anonymous D_Lambda) do (mkdir Task05\%%V\%%D\out 2>nul & javac -d Task05\%%V\%%D\out Task05\%%V\%%D\Converter.java)
mkdir Task05\CompleteTheCode\out 2>nul
javac -d Task05\CompleteTheCode\out Task05\CompleteTheCode\Converter.java
cd Task06 & call compile.bat

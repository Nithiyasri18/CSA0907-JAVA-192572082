import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ComparatorTests {
    static class Team {
        final String name; final int points, goalDiff;
        Team(String n, int p, int g) { name = n; points = p; goalDiff = g; }
        public String toString() { return name + "(" + points + "," + goalDiff
                + ")"; }
    }

    static final Comparator<Team> GOALDIFF_DESC =
        Comparator.comparingInt((Team t) -> t.goalDiff).reversed();

    // Correct: points desc, goal difference desc, name A-Z (no subtraction)
    static final Comparator<Team> CORRECT =
        Comparator.comparingInt((Team t) -> t.points).reversed()
            .thenComparing(GOALDIFF_DESC)
            .thenComparing(t -> t.name);

    // Faulty 1: compares points only (ignores both tie-breakers)
    static final Comparator<Team> POINTS_ONLY =
        (a, b) -> Integer.compare(b.points, a.points);

    // Faulty 2: points and goal difference, but no name tie-breaker
    static final Comparator<Team> NO_NAME =
        Comparator.comparingInt((Team t) -> t.points).reversed()
        .thenComparing(GOALDIFF_DESC);

    // Faulty 3: goal difference compared by subtraction (can overflow)
    static final Comparator<Team> SUBTRACT = (a, b) ->
        b.points != a.points ? Integer.compare(b.points, a.points)
        : b.goalDiff - a.goalDiff != 0 ? b.goalDiff - a.goalDiff
        : a.name.compareTo(b.name);

    static List<Team> sorted(List<Team> in, Comparator<Team> c) {
        List<Team> copy = new ArrayList<>(in);
        copy.sort(c);                                   // List.sort is stable
        return copy;
    }

    static String names(List<Team> list) {
        StringBuilder sb = new StringBuilder();
        for (Team t : list) sb.append(t.name).append(' ');
        return sb.toString().trim();
    }

    static void show(String title, List<Team> data) {
        System.out.println(title);
        System.out.println("  input        : " + names(data));
        System.out.println("  correct      : " + names(sorted(data, CORRECT)));
        System.out.println("  points only  : "
                + names(sorted(data, POINTS_ONLY)));
        System.out.println("  no name rule : " + names(sorted(data, NO_NAME)));
        System.out.println("  subtraction  : " + names(sorted(data, SUBTRACT)));
    }

    public static void main(String[] args) {
        // Data set 1: several ties at every level
        List<Team> set1 = List.of(new Team("Panthers", 9, 4), new Team("Eagles",
                9, 6),
            new Team("Cobras", 6, 1), new Team("Bisons", 9, 4),
                    new Team("Falcons", 9, 6),
            new Team("Hawks", 6, 1), new Team("Dolphins", 6, 3), new Team("Ibex",
                    3, 0));
        show("Data set 1 (ties at every level)", set1);

        // Data set 2: built to break the faulty comparators
        List<Team> set2 = List.of(new Team("Zebras", 7, 3), new Team("Yaks", 7,
                3),
            new Team("Tigers", 7, -2), new Team("Lions", 7, 5),
            new Team("Xerus", 5, 2_000_000_000), new Team("Wolves", 5,
                    -2_000_000_000),
            new Team("Vipers", 5, 0), new Team("Aces", 9, 1));
        show("Data set 2 (designed to expose faults)", set2);
    }
}

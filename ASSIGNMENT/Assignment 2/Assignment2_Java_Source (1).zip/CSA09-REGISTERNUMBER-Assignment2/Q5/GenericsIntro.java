import java.util.ArrayList;
import java.util.List;

class Box<T> {                       // T is chosen by the caller
    private final T value;
    Box(T value) { this.value = value; }
    T get() { return value; }
}

public class GenericsIntro {
    public static void main(String[] args) {
        Box<String> name = new Box<>("Arun");
        String s = name.get();                    // no cast needed
        Box<Integer> marks = new Box<>(87);
        int m = marks.get();
        System.out.println(s + " " + m);

        List<String> teams = new ArrayList<>();
        teams.add("Eagles");
        // teams.add(42);   // compile-time error: only String is allowed
        System.out.println(teams);
    }
}

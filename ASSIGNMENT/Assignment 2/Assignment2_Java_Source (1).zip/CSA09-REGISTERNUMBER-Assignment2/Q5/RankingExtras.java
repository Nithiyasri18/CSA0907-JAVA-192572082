import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class RankingExtras {

    // Comparable alternative
    static class Team implements Comparable<Team> {
        final String name; final int points, goalDiff;
        Team(String n, int p, int g) { name = n; points = p; goalDiff = g; }
        // one natural order only
        @Override public int compareTo(Team o) {
            if (points != o.points) return Integer.compare(o.points, points);
            if (goalDiff != o.goalDiff) {
                return Integer.compare(o.goalDiff, goalDiff);
            }
            return name.compareTo(o.name);
        }
        public String toString() {
            return name + "(" + points + "," + goalDiff + ")";
        }
    }

    static class VarsityTeam extends Team {
        VarsityTeam(String n, int p, int g) { super(n, p, g); }
    }

    // Bounded type: T must be able to compare itself (or a supertype of itself)
    static <T extends Comparable<? super T>> List<T> rankNatural(List<T> in) {
        List<T> copy = new ArrayList<>(in);
        Collections.sort(copy);
        return copy;
    }

    // Wildcard: reads from a List of any subtype of T; comparator may be for a
    // supertype
    static <T> List<T> rank(List<? extends T> source,
            Comparator<? super T> order) {
        List<T> copy = new ArrayList<>(source);
        copy.sort(order);
        return copy;
    }

    public static void main(String[] args) {
        List<Team> teams = List.of(new Team("Panthers", 9, 4), new Team("Eagles",
                9, 6),
            new Team("Cobras", 6, 1), new Team("Bisons", 9, 4));
        System.out.println("Comparable : " + rankNatural(teams));

        // three stable sorts: least important key first
        List<Team> s = new ArrayList<>(teams);
        s.sort(Comparator.comparing((Team t) -> t.name));
        s.sort(Comparator.comparingInt((Team t) -> t.goalDiff).reversed());
        s.sort(Comparator.comparingInt((Team t) -> t.points).reversed());
        System.out.println("3 stable sorts: " + s);
        System.out.println("same as Comparable: " + s.toString()
                .equals(rankNatural(teams).toString()));

        List<VarsityTeam> v = List.of(new VarsityTeam("Rams", 4, 0),
                new VarsityTeam("Owls", 6, 2));
        Comparator<Team> byPoints = Comparator.comparingInt((Team t) -> t.points)
                .reversed();
        // List<VarsityTeam> accepted
        List<Team> ranked = rank(v, byPoints);
        System.out.println("Wildcard   : " + ranked);
    }
}

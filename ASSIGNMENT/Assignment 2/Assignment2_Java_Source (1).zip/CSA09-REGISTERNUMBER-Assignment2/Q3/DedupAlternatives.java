import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;

public class DedupAlternatives {
    // no equals()/hashCode() needed here
    static class Student {
        final String regNo, name;
        Student(String r, String n) { regNo = r; name = n; }
        public String toString() { return regNo + " " + name; }
    }

    public static void main(String[] args) {
        String[][] scans = {{"192311001", "Arun"}, {"192311002", "Divya"},
                {"192311001", "Arun"}};

        TreeSet<Student> tree =
                new TreeSet<>(Comparator.comparing((Student s) -> s.regNo));
        Map<String, Student> map = new HashMap<>();
        for (String[] sc : scans) {
            Student s = new Student(sc[0], sc[1]);
            // comparator result 0 => duplicate, ignored
            tree.add(s);
            map.putIfAbsent(s.regNo, s);           // existing key => ignored
        }
        System.out.println("TreeSet size = " + tree.size() + " " + tree);
        System.out.println("HashMap size = " + map.size() + " " + map.values());
    }
}

import java.util.HashSet;
import java.util.Set;

public class HashContractTests {

    // equals() on regNo, hashCode() NOT overridden (the junior developer's class)
    static class BrokenStudent {
        final String regNo, name;
        BrokenStudent(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) {
            if (!(o instanceof BrokenStudent)) return false;
            return regNo.equals(((BrokenStudent) o).regNo);
        }
    }

    // corrected: hashCode() uses the same field as equals()
    static class GoodStudent {
        final String regNo, name;
        GoodStudent(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) {
            if (!(o instanceof GoodStudent)) return false;
            return regNo.equals(((GoodStudent) o).regNo);
        }
        @Override public int hashCode() { return regNo.hashCode(); }
    }

    // hashCode() is correct, but the field it uses is NOT final
    static class MutableStudent {
        String regNo; final String name;
        MutableStudent(String r, String n) { regNo = r; name = n; }
        @Override public boolean equals(Object o) {
            if (!(o instanceof MutableStudent)) return false;
            return regNo.equals(((MutableStudent) o).regNo);
        }
        @Override public int hashCode() { return regNo.hashCode(); }
    }

    public static void main(String[] args) {
        // Test 1: the same object is scanned twice (predicted size 2 for both
        // classes)
        Set<BrokenStudent> b1 = new HashSet<>();
        BrokenStudent arunB = new BrokenStudent("192311001", "Arun");
        b1.add(arunB);
        b1.add(new BrokenStudent("192311002", "Divya"));
        b1.add(arunB);                                     // same reference again
        Set<GoodStudent> g1 = new HashSet<>();
        GoodStudent arunG = new GoodStudent("192311001", "Arun");
        g1.add(arunG);
        g1.add(new GoodStudent("192311002", "Divya"));
        g1.add(arunG);
        System.out.println("Test 1  broken class: " + b1.size()
                + "   corrected class: " + g1.size());

        // Test 2: two DIFFERENT objects with the same regNo (predicted 3 vs 2)
        Set<BrokenStudent> b2 = new HashSet<>();
        b2.add(new BrokenStudent("192311001", "Arun"));
        b2.add(new BrokenStudent("192311002", "Divya"));
        b2.add(new BrokenStudent("192311001", "Arun"));
        Set<GoodStudent> g2 = new HashSet<>();
        g2.add(new GoodStudent("192311001", "Arun"));
        g2.add(new GoodStudent("192311002", "Divya"));
        g2.add(new GoodStudent("192311001", "Arun"));
        System.out.println("Test 2  broken class: " + b2.size()
                + "   corrected class: " + g2.size());
        BrokenStudent x = new BrokenStudent("192311001", "Arun");
        BrokenStudent y = new BrokenStudent("192311001", "Arun");
        System.out.println("        broken: equals=" + x.equals(y)
            + ", same hashCode=" + (x.hashCode() == y.hashCode()));

        // Test 3: regNo is changed AFTER the object is stored in the set
        Set<MutableStudent> m = new HashSet<>();
        MutableStudent s = new MutableStudent("192311001", "Arun");
        m.add(s);
        System.out.println("Test 3  before change: size=" + m.size()
                + ", contains=" + m.contains(s));
        s.regNo = "192311999";
        System.out.println("        after change : size=" + m.size()
                + ", contains=" + m.contains(s)
            + ", remove=" + m.remove(s));
        m.add(new MutableStudent("192311001", "Arun"));
        System.out.println("        add original regNo again: size=" + m.size());
    }
}

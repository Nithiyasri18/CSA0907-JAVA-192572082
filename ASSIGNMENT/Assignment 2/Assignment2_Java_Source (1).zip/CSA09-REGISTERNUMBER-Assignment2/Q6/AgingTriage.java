import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

// Fairness rule: for every AGE_STEP service ticks a patient has waited, the
// effective severity improves by one level (never better than S1).
public class AgingTriage {
    static class Patient {
        final String name; final int severity; final long arrival;
        final long arrivedAt;
        int effective;
        Patient(String n, int s, long a, long t) {
            name = n; severity = s; arrival = a; arrivedAt = t; effective = s;
        }
        public String toString() { return name + "(S" + severity + ")"; }
    }

    private final int ageStep;           // 0 = ageing switched off
    private long counter = 0, now = 0;   // now = number of patients served so far
    private final PriorityQueue<Patient> queue = new PriorityQueue<>(
        Comparator.comparingInt((Patient p) -> p.effective)
                  .thenComparingLong(p -> p.arrival));

    AgingTriage(int ageStep) { this.ageStep = ageStep; }

    void admit(String name, int severity) {
        queue.add(new Patient(name, severity, counter++, now));
    }

    Patient next() {
        // re-rank everybody before serving
        if (ageStep > 0) {
            List<Patient> all = new ArrayList<>(queue);
            queue.clear();
            for (Patient p : all) {
                p.effective = Math.max(1,
                        p.severity - (int) ((now - p.arrivedAt) / ageStep));
                queue.add(p);
            }
        }
        now++;
        return queue.poll();
    }

    static String simulate(int ageStep, int rounds) {
        AgingTriage er = new AgingTriage(ageStep);
        // minor case, waiting since time 0
        er.admit("Asha", 5);
        StringBuilder log = new StringBuilder();
        for (int r = 1; r <= rounds; r++) {
            // a new critical patient every round
            er.admit("C" + r, 1);
            // the doctor sees one patient per round
            Patient p = er.next();
            log.append(p.name).append(' ');
            if (p.name.equals("Asha")) { log.append("<-- Asha served in round "
                    + r); break; }
        }
        return log.toString().trim();
    }

    public static void main(String[] args) {
        System.out.println("Without ageing: " + simulate(0, 30));
        System.out.println("With ageing (step 5): " + simulate(5, 30));
    }
}

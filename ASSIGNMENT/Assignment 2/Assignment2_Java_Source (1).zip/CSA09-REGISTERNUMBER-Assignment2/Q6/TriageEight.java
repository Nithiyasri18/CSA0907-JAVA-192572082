import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

public class TriageEight {
    static class Patient {
        final String name; final int severity; final long arrival;
        Patient(String n, int s, long a) { name = n; severity = s; arrival = a; }
        public String toString() { return name + "(S" + severity + ",#" + arrival
                + ")"; }
    }

    // Shows the waiting list in treatment order without disturbing the real queue
    static String waitingList(PriorityQueue<Patient> queue) {
        PriorityQueue<Patient> copy = new PriorityQueue<>(queue);
        StringBuilder sb = new StringBuilder();
        Patient p;
        while ((p = copy.poll()) != null) sb.append(p.name).append(' ');
        return sb.toString().trim();
    }

    public static void main(String[] args) {
        PriorityQueue<Patient> queue = new PriorityQueue<>(
            Comparator.comparingInt((Patient p) -> p.severity)
                      .thenComparingLong(p -> p.arrival));

        String[] names = {"Anil", "Bhavna", "Charan", "Deepa", "Esha", "Farid",
                "Gita", "Hari"};
        int[] severity = {4, 2, 4, 1, 2, 5, 1, 3};
        for (int i = 0; i < names.length; i++) queue.add(new Patient(names[i],
                severity[i], i));

        // Hand-worked order (see the step-by-step table in the report)
        List<String> expected = Arrays.asList("Deepa", "Gita", "Bhavna", "Esha",
                                              "Hari", "Anil", "Charan", "Farid");

        System.out.println("Printing the PriorityQueue directly (heap order):");
        System.out.println("  " + queue);
        System.out.println("Waiting list in treatment order (copy is drained):");
        System.out.println("  " + waitingList(queue));

        List<String> served = new ArrayList<>();
        System.out.println("Serving with poll():");
        Patient p;
        while ((p = queue.poll()) != null) {
            served.add(p.name);
            System.out.println("  " + served.size() + ". " + p);
        }
        System.out.println("Matches hand-verified order: "
                + served.equals(expected));
    }
}

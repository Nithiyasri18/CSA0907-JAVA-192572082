import java.io.PrintWriter;
import java.util.*;

public class TriageBenchmark {
    static class Patient {
        final int severity; final long arrival;
        Patient(int s, long a) { severity = s; arrival = a; }
    }

    static final int K = 1000, TRIALS = 5, WARMUP = 2;
    static final Comparator<Patient> RULE =
        Comparator.comparingInt((Patient p) -> p.severity)
                .thenComparingLong(p -> p.arrival);
    static final String[] DESIGNS = {"PriorityQueue", "SortedLinkedList",
            "FiveQueues"};
    static long sink;

    // The three designs share one tiny interface so the same workload drives all
    // of them
    interface Triage { void admit(Patient p); Patient next(); }

    static Triage create(int design, List<Patient> preload) {
        if (design == 0) {
            PriorityQueue<Patient> pq = new PriorityQueue<>(RULE);
            pq.addAll(preload);
            return new Triage() {
                public void admit(Patient p) { pq.add(p); }
                public Patient next() { return pq.poll(); }
            };
        } else if (design == 1) {
            LinkedList<Patient> list = new LinkedList<>(preload);
            // start from a sorted list
            list.sort(RULE);
            return new Triage() {
                // walk to the correct position: O(n)
                public void admit(Patient p) {
                    ListIterator<Patient> it = list.listIterator();
                    while (it.hasNext()) {
                        if (it.next().severity > p.severity) { it.previous();
                        break; }
                    }
                    it.add(p);
                }
                public Patient next() { return list.pollFirst(); }
            };
        } else {
            List<ArrayDeque<Patient>> q = new ArrayList<>();
            for (int i = 0; i < 5; i++) q.add(new ArrayDeque<>());
            for (Patient p : preload) q.get(p.severity - 1).addLast(p);
            return new Triage() {
                public void admit(Patient p) { q.get(p.severity - 1).addLast(p); }
                public Patient next() {
                    for (ArrayDeque<Patient> level : q)
                        if (!level.isEmpty()) return level.pollFirst();
                    return null;
                }
            };
        }
    }

    public static void main(String[] args) throws Exception {
        try (PrintWriter csv = new PrintWriter("q6_raw.csv")) {
            csv.println("size,design,operation,trial,ops,total_ns");
            for (int n : new int[]{1_000, 10_000, 100_000}) {
                Random r = new Random(5);
                List<Patient> preload = new ArrayList<>();
                for (int i = 0; i < n; i++) {
                    preload.add(new Patient(1 + r.nextInt(5), i));
                }
                List<Patient> arrivals = new ArrayList<>();
                for (int i = 0; i < K; i++) {
                    arrivals.add(new Patient(1 + r.nextInt(5), n + i));
                }

                double[][] add = new double[3][TRIALS];
                double[][] poll = new double[3][TRIALS];
                for (int d = 0; d < 3; d++)                       // warm-up
                    for (int w = 0; w < WARMUP; w++) {
                        Triage t = create(d, preload);
                        for (Patient p : arrivals) t.admit(p);
                        for (int i = 0; i < K; i++) sink += t.next().severity;
                    }
                for (int trial = 0; trial < TRIALS; trial++) {
                    for (int d = 0; d < 3; d++) {
                        // untimed set-up
                        Triage t = create(d, preload);
                        long t0 = System.nanoTime();
                        for (Patient p : arrivals) t.admit(p);
                        add[d][trial] = System.nanoTime() - t0;
                        t0 = System.nanoTime();
                        for (int i = 0; i < K; i++) sink += t.next().severity;
                        poll[d][trial] = System.nanoTime() - t0;
                        String id = n + "," + DESIGNS[d];
                        String tail = "," + (trial + 1) + "," + K + ",";
                        csv.println(id + ",admit" + tail + (long) add[d][trial]);
                        csv.println(id + ",serve" + tail + (long) poll[d][trial]);
                    }
                }
                for (int d = 0; d < 3; d++) {
                    double a = 0, p = 0;
                    for (int i = 0; i < TRIALS; i++) { a += add[d][i];
                    p += poll[d][i]; }
                    System.out.printf("%7d %-17s admit %10.1f ns/op"
                        + "   serve %10.1f ns/op%n",
                        n, DESIGNS[d], a / TRIALS / K, p / TRIALS / K);
                }
            }
        }
        System.out.println("sink (ignore) = " + sink);
    }
}

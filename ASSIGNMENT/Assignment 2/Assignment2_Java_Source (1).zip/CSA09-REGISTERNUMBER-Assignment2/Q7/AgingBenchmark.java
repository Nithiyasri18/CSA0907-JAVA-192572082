import java.io.PrintWriter;
import java.util.*;

public class AgingBenchmark {
    static final int AGE_STEP = 20, ROUNDS = 200, TRIALS = 5, WARMUP = 1;
    static long sink;

    static class Patient {
        final int id, severity;
        final long arrivedAt;
        int effective;
        Patient(int id, int severity, long arrivedAt) {
            this.id = id; this.severity = severity; this.arrivedAt = arrivedAt;
            this.effective = severity;
        }
    }

    // Fairness rule: one level better for every AGE_STEP services waited, never
    // better than S1
    static int effective(Patient p, long now) {
        return Math.max(1, p.severity - (int) ((now - p.arrivedAt) / AGE_STEP));
    }

    interface Triage { void admit(int severity); int next(); long visits(); }

    // ORIGINAL (Q6): before every service, re-rank all waiting patients -> O(n)
    // per service
    static class RescanTriage implements Triage {
        int ids = 0; long now = 0, visits = 0;
        final PriorityQueue<Patient> queue = new PriorityQueue<>(
            Comparator.comparingInt((Patient p) -> p.effective)
                    .thenComparingInt(p -> p.id));
        public void admit(int s) { queue.add(new Patient(ids++, s, now)); }
        public int next() {
            List<Patient> all = new ArrayList<>(queue);
            queue.clear();
            for (Patient p : all) { p.effective = effective(p, now);
            queue.add(p); visits++; }
            now++;
            return queue.poll().id;
        }
        public long visits() { return visits; }
    }

    // REDESIGN: one FIFO queue per ORIGINAL severity. Inside one queue the oldest
    // patient
    // is always the best-ranked, so only the five queue heads need to be
    // compared.
    static class HeadsTriage implements Triage {
        int ids = 0; long now = 0, visits = 0;
        final List<ArrayDeque<Patient>> level = new ArrayList<>();
        HeadsTriage() {
            for (int i = 0; i < 5; i++) level.add(new ArrayDeque<>());
        }
        public void admit(int s) { level.get(s - 1).addLast(new Patient(ids++, s,
                now)); }
        public int next() {
            Patient best = null;
            int bestEff = 0;
            for (ArrayDeque<Patient> q : level) {
                Patient h = q.peekFirst();
                if (h == null) continue;
                visits++;
                int e = effective(h, now);
                boolean better = best == null || e < bestEff
                        || (e == bestEff && h.id < best.id);
                if (better) {
                    best = h; bestEff = e;
                }
            }
            now++;
            level.get(best.severity - 1).pollFirst();
            return best.id;
        }
        public long visits() { return visits; }
    }

    static Triage create(int design) { return design == 0 ? new RescanTriage()
            : new HeadsTriage(); }
    static final String[] DESIGNS = {"RescanPQ(original)", "FiveHeads(redesign)"};

    // Correctness: random interleaved admit/serve stream must give identical
    // service order
    static boolean sameOrder(int operations, long seed) {
        Random r = new Random(seed);
        Triage a = create(0), b = create(1);
        int waiting = 0;
        for (int i = 0; i < operations; i++) {
            if (waiting == 0 || r.nextInt(10) < 6) {
                int s = 1 + r.nextInt(5);
                a.admit(s); b.admit(s); waiting++;
            } else {
                if (a.next() != b.next()) return false;
                waiting--;
            }
        }
        return true;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("Random-stream equivalence (3 seeds): "
            + (sameOrder(5000, 1) && sameOrder(5000, 2) && sameOrder(5000, 3)));
        try (PrintWriter csv = new PrintWriter("q7_raw.csv")) {
            csv.println("size,design,trial,rounds,total_ns,patient_visits");
            for (int n : new int[]{1_000, 10_000, 100_000}) {
                Random r = new Random(9);
                int[] pre = new int[n], later = new int[ROUNDS];
                for (int i = 0; i < n; i++) pre[i] = 1 + r.nextInt(5);
                for (int i = 0; i < ROUNDS; i++) later[i] = 1 + r.nextInt(5);

                int[][] served = new int[2][ROUNDS];
                double[] ns = new double[2], visits = new double[2];
                for (int d = 0; d < 2; d++)                       // warm-up
                    for (int w = 0; w < WARMUP; w++) {
                        Triage t = create(d);
                        for (int s : pre) t.admit(s);
                        for (int i = 0; i < ROUNDS; i++) { sink += t.next();
                        t.admit(later[i]); }
                    }
                for (int trial = 1; trial <= TRIALS; trial++) {
                    for (int d = 0; d < 2; d++) {
                        // untimed set-up
                        Triage t = create(d);
                        for (int s : pre) t.admit(s);
                        long t0 = System.nanoTime();
                        for (int i = 0; i < ROUNDS; i++) {
                            // serve one patient ...
                            served[d][i] = t.next();
                            // ... and one new arrival
                            t.admit(later[i]);
                        }
                        long total = System.nanoTime() - t0;
                        ns[d] += total; visits[d] = t.visits();
                        String id = n + "," + DESIGNS[d] + "," + trial;
                        csv.println(id + "," + ROUNDS + ","
                                + total + "," + t.visits());
                    }
                }
                System.out.println("size " + n + ": identical service order = "
                    + Arrays.equals(served[0], served[1]));
                for (int d = 0; d < 2; d++)
                    System.out.printf("  %-20s avg %14.0f ns per %d rounds,"
                        + " patient visits = %d%n",
                        DESIGNS[d], ns[d] / TRIALS, ROUNDS, (long) visits[d]);
                System.out.printf("  speed-up (original / redesign) = %.1f x%n",
                        ns[0] / ns[1]);
            }
        }
        System.out.println("sink (ignore) = " + sink);
    }
}

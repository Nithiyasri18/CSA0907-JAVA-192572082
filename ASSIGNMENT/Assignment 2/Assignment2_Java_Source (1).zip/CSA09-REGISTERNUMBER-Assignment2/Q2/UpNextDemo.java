import java.util.ArrayDeque;
import java.util.Deque;

public class UpNextDemo {
    public static void main(String[] args) {
        Deque<String> upNext = new ArrayDeque<>();
        upNext.addLast("Track B");     // added at the back of the queue
        upNext.addLast("Track C");
        upNext.addFirst("Urgent A");   // "play next" goes to the front
        System.out.println("Queue: " + upNext);
        String playing = upNext.removeFirst();
        System.out.println("Now playing: " + playing);
        System.out.println("Queue: " + upNext);
    }
}

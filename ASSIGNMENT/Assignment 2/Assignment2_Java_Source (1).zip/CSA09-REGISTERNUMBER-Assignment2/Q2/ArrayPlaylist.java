import java.util.Arrays;

public class ArrayPlaylist {
    private String[] songs = new String[4];
    private int size = 0;

    void add(String s) {                    // O(1) amortised: copy only when full
        if (size == songs.length) songs = Arrays.copyOf(songs, size * 2);
        songs[size++] = s;
    }

    void insert(int index, String s) {      // O(n - index): shift the tail right
        if (size == songs.length) songs = Arrays.copyOf(songs, size * 2);
        for (int i = size; i > index; i--) songs[i] = songs[i - 1];
        songs[index] = s;
        size++;
    }

    String remove(int index) {              // O(n - index): shift the tail left
        String removed = songs[index];
        for (int i = index; i < size - 1; i++) songs[i] = songs[i + 1];
        songs[--size] = null;
        return removed;
    }

    String get(int k) { return songs[k]; }  // O(1)

    public static void main(String[] args) {
        ArrayPlaylist p = new ArrayPlaylist();
        p.add("A"); p.add("B"); p.add("C");
        p.insert(0, "Opening");
        p.insert(2, "Middle");
        System.out.println(Arrays.toString(Arrays.copyOf(p.songs, p.size)));
        System.out.println("removed " + p.remove(0) + ", get(2) = " + p.get(2));
        System.out.println(Arrays.toString(Arrays.copyOf(p.songs, p.size)));
    }
}

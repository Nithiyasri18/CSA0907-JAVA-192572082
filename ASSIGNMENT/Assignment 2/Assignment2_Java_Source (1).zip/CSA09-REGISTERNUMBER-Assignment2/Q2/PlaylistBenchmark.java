import java.io.PrintWriter;
import java.util.*;

public class PlaylistBenchmark {
    static final int OPS = 500, TRIALS = 5, WARMUP = 2;
    static final String[] STRUCTS = {"ArrayList", "LinkedList", "ArrayDeque"};
    static final String[] OPNAMES = {"addEnd", "addFront", "addMiddle",
            "removeFront",
        "removeMiddle", "getKth", "upNext", "iterate"};
    // consumed so work is not optimised away
    static long sink;

    static Collection<String> make(int s, String[] songs) {
        List<String> base = Arrays.asList(songs);
        if (s == 0) return new ArrayList<>(base);
        if (s == 1) return new LinkedList<>(base);
        return new ArrayDeque<>(base);
    }

    // ArrayDeque has no index, so it only takes part in end/front/iterate tests
    static boolean supported(String op, int s) {
        if (s != 2) return true;
        return !(op.equals("addMiddle") || op.equals("removeMiddle")
                || op.equals("getKth"));
    }

    // returns the number of operations performed
    static int run(String op, Collection<String> c, int[] idx, int passes) {
        List<String> list = (c instanceof List) ? (List<String>) c : null;
        Deque<String> dq = (c instanceof List) ? null : (Deque<String>) c;
        switch (op) {
            case "addEnd":
                for (int i = 0; i < OPS; i++) {
                    if (list != null) list.add("NEW"); else dq.addLast("NEW");
                }
                return OPS;
            case "addFront":
                for (int i = 0; i < OPS; i++) {
                    if (list != null) list.add(0, "NEW"); else dq.addFirst("NEW");
                }
                return OPS;
            case "addMiddle":
                for (int i = 0; i < OPS; i++) list.add(list.size() / 2, "NEW");
                return OPS;
            case "removeFront":
                for (int i = 0; i < OPS; i++) {
                    String first = (list != null)
                            ? list.remove(0) : dq.removeFirst();
                    sink += first.length();
                }
                return OPS;
            case "removeMiddle":
                for (int i = 0; i < OPS; i++) {
                    sink += list.remove(list.size() / 2).length();
                }
                return OPS;
            case "getKth":
                for (int i = 0; i < OPS; i++) sink += list.get(idx[i]).length();
                return OPS;
            // add at end, add at front, play (remove) front
            case "upNext":
                for (int i = 0; i < OPS; i++) {
                    if (list != null) {
                        list.add("NEW"); list.add(0, "URGENT");
                        sink += list.remove(0).length();
                    } else {
                        dq.addLast("NEW"); dq.addFirst("URGENT");
                        sink += dq.removeFirst().length();
                    }
                }
                return OPS;
            // iterate: one operation = one full pass
            default:
                for (int p = 0; p < passes; p++)
                    for (String s : c) sink += s.length();
                return passes;
        }
    }

    public static void main(String[] args) throws Exception {
        int[] sizes = {1_000, 10_000, 100_000};
        try (PrintWriter csv = new PrintWriter("q2_raw.csv")) {
            csv.println("size,structure,operation,trial,ops,total_ns");
            for (int size : sizes) {
                String[] songs = new String[size];
                for (int i = 0; i < size; i++) songs[i] = "Song" + i;
                Random r = new Random(7);
                int[] idx = new int[OPS];
                for (int i = 0; i < OPS; i++) idx[i] = r.nextInt(size);
                int passes = Math.max(1, 1_000_000 / size);

                for (String op : OPNAMES) {
                    long[][] total = new long[3][TRIALS];
                    int ops = 0;
                    for (int s = 0; s < 3; s++)                       // warm-up
                        if (supported(op, s))
                            for (int w = 0; w < WARMUP; w++)
                                run(op, make(s, songs), idx, passes);
                    for (int t = 0; t < TRIALS; t++) {
                        for (int s = 0; s < 3; s++) {
                            if (!supported(op, s)) continue;
                            // fresh, untimed
                            Collection<String> c = make(s, songs);
                            long t0 = System.nanoTime();
                            ops = run(op, c, idx, passes);
                            total[s][t] = System.nanoTime() - t0;
                            csv.println(size + "," + STRUCTS[s] + "," + op + ","
                                + (t + 1) + "," + ops + "," + total[s][t]);
                        }
                    }
                    StringBuilder line =
                        new StringBuilder(String.format("%7d %-12s", size, op));
                    for (int s = 0; s < 3; s++) {
                        if (!supported(op, s)) {
                            line.append(String.format(" %14s", "n/a"));
                            continue;
                        }
                        double sum = 0;
                        for (long v : total[s]) sum += v;
                        line.append(String.format(" %14.1f", sum / TRIALS / ops));
                    }
                    System.out.println(line);
                }
            }
        }
        System.out.println("columns: ArrayList  LinkedList  ArrayDeque"
                + "  (average ns per operation)");
        System.out.println("sink (ignore) = " + sink);
    }
}

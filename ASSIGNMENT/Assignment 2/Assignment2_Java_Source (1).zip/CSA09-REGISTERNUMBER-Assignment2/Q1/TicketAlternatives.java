import java.util.StringJoiner;

public class TicketAlternatives {
    public static void main(String[] args) {
        String[] f = {"PNR=2345678901", "NAME=Arun", "COACH=S4", "BERTH=32",
                "FARE=745.50"};

        StringBuilder b = new StringBuilder();
        for (int i = 0; i < f.length; i++) {
            if (i > 0) b.append('|');
            b.append(f[i]);
        }
        String viaBuilder = b.toString();

        String viaJoin = String.join("|", f);

        StringJoiner j = new StringJoiner("|");
        for (String x : f) j.add(x);
        String viaJoiner = j.toString();

        String viaFormat = String.format("%s|%s|%s|%s|%s", (Object[]) f);

        System.out.println(viaBuilder);
        System.out.println("join   equals builder: "
                + viaJoin.equals(viaBuilder));
        System.out.println("joiner equals builder: "
                + viaJoiner.equals(viaBuilder));
        System.out.println("format equals builder: "
                + viaFormat.equals(viaBuilder));
    }
}

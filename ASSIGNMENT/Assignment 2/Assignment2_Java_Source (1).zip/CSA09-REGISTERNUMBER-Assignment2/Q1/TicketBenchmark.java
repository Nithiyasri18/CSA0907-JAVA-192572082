import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class TicketBenchmark {

    // Four ways to build the same ticket (every field already ends with '|')
    static String viaString(String[] f) {
        String s = "";
        for (String x : f) s = s + x;
        return s;
    }

    static String viaBuilder(String[] f) {
        StringBuilder b = new StringBuilder();
        for (String x : f) b.append(x);
        return b.toString();
    }

    static String viaBuffer(String[] f) {
        StringBuffer b = new StringBuffer();
        for (String x : f) b.append(x);
        return b.toString();
    }

    static String viaJoin(String[] f) {
        return String.join("", f);
    }

    static final String[] METHODS =
        {"String", "StringBuilder", "StringBuffer", "String.join"};

    static String build(int m, String[] f) {
        switch (m) {
            case 0:  return viaString(f);
            case 1:  return viaBuilder(f);
            case 2:  return viaBuffer(f);
            default: return viaJoin(f);
        }
    }

    // Distinct ticket data, generated once from a fixed seed
    static String[][] makeTickets(int tickets, int fields, int minLen,
                                  int maxLen, long seed) {
        Random r = new Random(seed);
        String[][] t = new String[tickets][fields];
        for (int i = 0; i < tickets; i++) {
            for (int j = 0; j < fields; j++) {
                int len = minLen + r.nextInt(maxLen - minLen + 1);
                StringBuilder v = new StringBuilder("F" + j + "=");
                for (int k = 0; k < len; k++) {
                    v.append((char) ('A' + r.nextInt(26)));
                }
                t[i][j] = v.append('|').toString();
            }
        }
        return t;
    }

    // One pass = build every ticket once; the returned length is consumed
    static long pass(int m, String[][] t) {
        long chars = 0;
        for (String[] f : t) chars += build(m, f).length();
        return chars;
    }

    static long allocatedBytes() {
        return ((com.sun.management.ThreadMXBean)
                ManagementFactory.getThreadMXBean())
                        .getCurrentThreadAllocatedBytes();
    }

    static long heapUsed() {
        Runtime rt = Runtime.getRuntime();
        return rt.totalMemory() - rt.freeMemory();
    }

    static final int WARMUP = 3, TRIALS = 5;

    public static void main(String[] args) throws Exception {
        String[] names = {"A", "B", "C"};
        // tickets, fields, minLen, maxLen, passes per trial
        int[][] cfg = {{1, 6, 4, 10, 20000},
                       {10000, 50, 5, 12, 1},
                       {1000, 200, 5, 12, 1}};
        long checksum = 0;
        try (PrintWriter csv = new PrintWriter("q1_raw.csv")) {
            csv.println("workload,method,trial,tickets,fields,passes,appends,"
                + "total_ns,ns_per_ticket,alloc_bytes_per_ticket");
            for (int w = 0; w < cfg.length; w++) {
                int tk = cfg[w][0], fl = cfg[w][1], passes = cfg[w][4];
                String[][] t = makeTickets(tk, fl, cfg[w][2], cfg[w][3], 42L);

                // correctness: all methods must give identical tickets
                boolean same = true;
                Set<String> distinct = new HashSet<>();
                for (String[] f : t) {
                    String ref = viaBuilder(f);
                    distinct.add(ref);
                    for (int m = 0; m < 4; m++) same &= ref.equals(build(m, f));
                }
                System.out.println("Workload " + names[w] + ": tickets=" + tk
                    + ", fields=" + fl + ", distinct tickets=" + distinct.size()
                    + ", outputs identical=" + same);

                for (int m = 0; m < 4; m++) {           // warm-up
                    for (int i = 0; i < WARMUP * passes; i++) {
                        checksum += pass(m, t);
                    }
                }

                System.gc();
                long heapBefore = heapUsed();
                double[][] ns = new double[4][TRIALS];
                double[][] bytes = new double[4][TRIALS];
                for (int trial = 0; trial < TRIALS; trial++) {
                    for (int k = 0; k < 4; k++) {
                        int m = (trial + k) % 4;       // rotate the order
                        long a0 = allocatedBytes(), t0 = System.nanoTime();
                        for (int p = 0; p < passes; p++) checksum += pass(m, t);
                        long total = System.nanoTime() - t0;
                        long alloc = allocatedBytes() - a0;
                        double per = (double) tk * passes;
                        ns[m][trial] = total / per;
                        bytes[m][trial] = alloc / per;
                        String row = names[w] + "," + METHODS[m] + ","
                                + (trial + 1);
                        row += "," + tk + "," + fl + "," + passes;
                        row += "," + (long) tk * fl * passes + "," + total;
                        row += "," + ns[m][trial] + "," + bytes[m][trial];
                        csv.println(row);
                    }
                }
                long heapAfter = heapUsed();
                System.out.println("  heap used before=" + heapBefore / 1024
                    + " KB, after=" + heapAfter / 1024 + " KB (approximate)");
                for (int m = 0; m < 4; m++) {
                    double sn = 0, sb = 0;
                    for (int i = 0; i < TRIALS; i++) {
                        sn += ns[m][i];
                        sb += bytes[m][i];
                    }
                    System.out.printf("  %-14s avg ns/ticket = %12.1f"
                        + "   avg bytes/ticket = %10.0f%n",
                        METHODS[m], sn / TRIALS, sb / TRIALS);
                }
            }
        }
        System.out.println("checksum (ignore) = " + checksum);
    }
}

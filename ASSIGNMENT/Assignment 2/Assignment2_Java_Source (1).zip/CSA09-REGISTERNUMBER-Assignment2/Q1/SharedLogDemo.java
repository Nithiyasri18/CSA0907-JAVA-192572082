import java.util.function.Consumer;
import java.util.function.IntSupplier;

public class SharedLogDemo {
    static final int THREADS = 4, APPENDS = 200_000;

    static int test(Consumer<String> add,
            IntSupplier length) throws InterruptedException {
        Thread[] ts = new Thread[THREADS];
        for (int i = 0; i < THREADS; i++) {
            ts[i] = new Thread(() -> {
                try {
                    for (int k = 0; k < APPENDS; k++) add.accept("x");
                } catch (RuntimeException e) {
                    System.out.println("  a thread failed: " + e);
                }
            });
            ts[i].start();
        }
        for (Thread t : ts) t.join();
        return length.getAsInt();
    }

    public static void main(String[] args) throws Exception {
        StringBuilder sb = new StringBuilder();
        StringBuffer sf = new StringBuffer();
        System.out.println("Expected length = " + THREADS * APPENDS);
        System.out.println("StringBuilder length = "
                + test(sb::append, sb::length));
        System.out.println("StringBuffer  length = "
                + test(sf::append, sf::length));
    }
}

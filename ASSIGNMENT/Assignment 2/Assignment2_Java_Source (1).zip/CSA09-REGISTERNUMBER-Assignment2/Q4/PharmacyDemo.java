import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

class Medicine {
    final String code, name;
    int stock;

    Medicine(String code, String name, int stock) {
        this.code = code;
        this.name = name;
        this.stock = stock;
    }

    public String toString() {
        return code + " " + name + " stock=" + stock;
    }
}

public class PharmacyDemo {
    public static void main(String[] args) {
        Map<String, Medicine> sorted = new TreeMap<>();
        Map<String, Medicine> added = new LinkedHashMap<>();
        Medicine[] data = {
            new Medicine("M103", "Paracetamol", 120),
            new Medicine("M101", "Saline", 45),
            new Medicine("M102", "Antiseptic", 30)
        };
        for (Medicine m : data) {
            sorted.put(m.code, m);
            added.put(m.code, m);
        }
        System.out.println("Lookup: " + sorted.get("M102"));
        System.out.println("Code order: " + sorted.values());
        System.out.println("Insertion order: " + added.values());
    }
}

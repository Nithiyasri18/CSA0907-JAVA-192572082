import java.io.PrintWriter;
import java.util.*;
import java.util.function.Supplier;

public class PharmacyBenchmark {

    static class Medicine {
        final String code, name;
        // seq = position in which it was added
        final int seq, stock;
        Medicine(String code, String name, int seq, int stock) {
            this.code = code; this.name = name; this.seq = seq;
            this.stock = stock;
        }
        String line() { return code + " " + name + " " + stock; }
    }

    static final int LOOKUPS = 100_000, INSERTS = 1_000, TRIALS = 5, WARMUP = 2;
    static final Comparator<Medicine> BY_CODE = Comparator.comparing(m -> m.code);
    static final Comparator<Medicine> BY_SEQ =
            Comparator.comparingInt(m -> m.seq);
    static final String[] KINDS = {"HashMap", "TreeMap", "LinkedHashMap",
            "SortedArray"};
    static long sink;
    static PrintWriter csv;
    static int size;

    // Array kept sorted by code and searched with Arrays.binarySearch()
    static class SortedArray {
        final String[] codes; final Medicine[] meds; int n;
        SortedArray(Medicine[] src, int spare) {
            Medicine[] c = src.clone();
            Arrays.sort(c, BY_CODE);
            codes = new String[c.length + spare];
            meds = new Medicine[c.length + spare];
            for (int i = 0; i < c.length; i++) {
                codes[i] = c[i].code;
                meds[i] = c[i];
            }
            n = c.length;
        }
        Medicine get(String code) {
            int i = Arrays.binarySearch(codes, 0, n, code);
            return i >= 0 ? meds[i] : null;
        }
        void insert(Medicine m) {             // shifts every later element: O(n)
            int i = -Arrays.binarySearch(codes, 0, n, m.code) - 1;
            System.arraycopy(codes, i, codes, i + 1, n - i);
            System.arraycopy(meds, i, meds, i + 1, n - i);
            codes[i] = m.code; meds[i] = m; n++;
        }
    }

    static Medicine[] makeMedicines(int n, String suffix, long seed) {
        List<Integer> ids = new ArrayList<>();
        for (int i = 0; i < n; i++) ids.add(i);
        Collections.shuffle(ids, new Random(seed));   // added order != code order
        Medicine[] m = new Medicine[n];
        for (int i = 0; i < n; i++) {
            int id = ids.get(i);
            String code = String.format("M%06d%s", id, suffix);
            m[i] = new Medicine(code, "Drug" + id, i, 10 + id % 90);
        }
        return m;
    }

    static Map<String, Medicine> newMap(int kind) {
        if (kind == 0) return new HashMap<>();
        if (kind == 1) return new TreeMap<>();
        return new LinkedHashMap<>();
    }

    static Map<String, Medicine> fill(int kind, Medicine[] data) {
        Map<String, Medicine> m = newMap(kind);
        for (Medicine d : data) m.put(d.code, d);
        return m;
    }

    // builds the report text (no printing)
    static int render(Collection<Medicine> c) {
        StringBuilder sb = new StringBuilder();
        for (Medicine m : c) sb.append(m.line()).append('\n');
        return sb.length();
    }

    // report in code order: free for TreeMap, otherwise copy + sort
    static Collection<Medicine> codeOrder(Map<String, Medicine> m) {
        if (m instanceof TreeMap) return m.values();
        List<Medicine> l = new ArrayList<>(m.values());
        l.sort(BY_CODE);
        return l;
    }

    // report in insertion order: free for LinkedHashMap, otherwise copy + sort by
    // seq
    static Collection<Medicine> insertionOrder(Map<String, Medicine> m) {
        if (m instanceof LinkedHashMap) return m.values();
        List<Medicine> l = new ArrayList<>(m.values());
        l.sort(BY_SEQ);
        return l;
    }

    static boolean inOrder(Collection<Medicine> c, Comparator<Medicine> cmp) {
        Medicine prev = null;
        for (Medicine m : c) {
            if (prev != null && cmp.compare(prev, m) > 0) return false;
            prev = m;
        }
        return true;
    }

    // setup is untimed; the Runnable it returns is the timed work
    static void bench(String kind, String op, int ops, Supplier<Runnable> setup) {
        for (int w = 0; w < WARMUP; w++) setup.get().run();
        double sum = 0;
        for (int t = 1; t <= TRIALS; t++) {
            Runnable task = setup.get();
            long t0 = System.nanoTime();
            task.run();
            long ns = System.nanoTime() - t0;
            sum += ns;
            csv.println(size + "," + kind + "," + op + "," + t + ","
                    + ops + "," + ns);
        }
        System.out.printf("%7d %-14s %-18s avg total = %14.0f ns"
                + "  (%10.1f ns/op)%n",
                size, kind, op, sum / TRIALS, sum / TRIALS / ops);
    }

    public static void main(String[] args) throws Exception {
        csv = new PrintWriter("q4_raw.csv");
        csv.println("size,structure,operation,trial,ops,total_ns");
        for (int n : new int[]{1_000, 10_000, 100_000}) {
            size = n;
            Medicine[] data = makeMedicines(n, "", 11L);
            Medicine[] extra = Arrays.copyOf(makeMedicines(n, "X", 22L), INSERTS);
            Random r = new Random(33);
            String[] keys = new String[LOOKUPS];
            for (int i = 0; i < LOOKUPS; i++) keys[i] = data[r.nextInt(n)].code;

            for (int k = 0; k < 4; k++) {
                final int kind = k;
                String name = KINDS[k];
                if (k < 3) {
                    Map<String, Medicine> m = fill(k, data);
                    System.out.println("order check " + name + " n=" + n
                        + ": natural code order=" + inOrder(m.values(), BY_CODE)
                        + ", natural insertion order="
                                + inOrder(m.values(), BY_SEQ)
                        + ", reports correct=" + (inOrder(codeOrder(m), BY_CODE)
                        && inOrder(insertionOrder(m), BY_SEQ)));
                    bench(name, "build(put all)", n,
                            () -> () -> sink += fill(kind, data).size());
                    bench(name, "lookup x100000", LOOKUPS, () -> () -> {
                        for (String key : keys) sink += m.get(key).stock;
                    });
                    bench(name, "insert x1000", INSERTS, () -> {
                        Map<String, Medicine> mm = fill(kind, data);
                        return () -> {
                            for (Medicine e : extra) mm.put(e.code, e);
                        };
                    });
                    bench(name, "report code order", n,
                            () -> () -> sink += render(codeOrder(m)));
                    bench(name, "report added order", n,
                            () -> () -> sink += render(insertionOrder(m)));
                } else {
                    SortedArray a = new SortedArray(data, 0);
                    List<Medicine> view = Arrays.asList(a.meds).subList(0, a.n);
                    System.out.println("order check SortedArray n=" + n
                            + ": natural code order="
                        + inOrder(view, BY_CODE) + ", natural insertion order="
                                + inOrder(view, BY_SEQ));
                    bench(name, "build(put all)", n,
                            () -> () -> sink += new SortedArray(data, 0).n);
                    bench(name, "lookup x100000", LOOKUPS, () -> () -> {
                        for (String key : keys) sink += a.get(key).stock;
                    });
                    bench(name, "insert x1000", INSERTS, () -> {
                        SortedArray s = new SortedArray(data, INSERTS);
                        return () -> { for (Medicine e : extra) s.insert(e); };
                    });
                    bench(name, "report code order", n,
                            () -> () -> sink += render(view));
                    bench(name, "report added order", n, () -> () -> {
                        List<Medicine> l = new ArrayList<>(view);
                        l.sort(BY_SEQ);
                        sink += render(l);
                    });
                }
            }
        }
        csv.close();
        System.out.println("sink (ignore) = " + sink);
    }
}

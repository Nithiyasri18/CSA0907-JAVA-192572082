# CSA09 – Programming in Java – Assignment 2 (CO2)

- **Name:** [YOUR NAME]
- **Register number:** [YOUR REGISTER NUMBER]
- **Java version:** [output of `java -version`]
- **Repository name must be:** CSA09-<RegisterNumber>-Assignment2

## How to compile and run (example, repeat inside each folder)
```
cd Q1
javac TicketBenchmark.java
java TicketBenchmark
```
Benchmark programs write their raw trial data to a CSV file in the folder they are run from
(`q1_raw.csv`, `q2_raw.csv`, `q4_raw.csv`, `q6_raw.csv`, `q7_raw.csv`). Commit these files.
All benchmark data is generated from fixed random seeds, so no separate input file is needed.

Q3 has two versions of `Attendance.java`: `before_TODO` (hashCode not overridden) and `after_TODO`.
Compile and run each inside its own folder.

## Result notes (fill in after running; one short note per task)
| Task | Programs | Result note |
|------|----------|-------------|
| Q1 | TicketBenchmark, SharedLogDemo, TicketAlternatives | [ ] |
| Q2 | PlaylistBenchmark, UpNextDemo, ArrayPlaylist | [ ] |
| Q3 | Attendance (before/after), HashContractTests, DedupAlternatives | [ ] |
| Q4 | PharmacyDemo, PharmacyBenchmark | [ ] |
| Q5 | LeaderboardDemo, ComparatorTests, RankingExtras, GenericsIntro | [ ] |
| Q6 | Triage, TriageEight, AgingTriage, TriageBenchmark | [ ] |
| Q7 | AgingBenchmark | [ ] |

Add an `screenshots/` folder in each task folder with the output screenshots.
